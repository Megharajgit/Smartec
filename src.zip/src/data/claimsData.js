export const claims = [
  {
    // id: "CLM-C-102942",
    id: "CLM-C-102942",
    platform: "CAS",
    source: "EDI 837",
    date: "10 Jun 2026 11:15 AM",
    member: "MBR-321251",
    provider: "ZTEST REGIONAL HOSPITAL",
    status: "Ready",
    priority: "High",
    show: "yes",
    workspaceType: "SPECIAL",
    validationScreens: {
      CAS: {
        buttons: [
          {
            id: "CAS",
            label: "View CAS Screen",
            image: "/smartec-claims/positive/s1_cas_initial.png",
          },
        ],

        fields: [
          {
            label: "Authorization Number (PRI)",
            value: "AUTH10000001",
          },
          {
            label: "Auth Status (PRI)",
            value: "Approved",
          },
          {
            label: "Requested Service (PRI)",
            value: "CPT 27447",
          },
          {
            label: "Approved Date Range (PRS)",
            value: "04/10/2026 – 04/13/2026",
          },
          {
            label: "Provider on Authorization (PRI)",
            value: "ZZTEST REGIONAL HOSPITAL",
          },
          {
            label: "Reviewed By (PRA)",
            value: "RN00045 — APP: Approved by Nurse (04/09/2026)",
          },
          {
            label: "Provider Tax ID (Claim Record)",
            value: "00-0000021",
          },
          {
            label: "Place of Treatment (POT)",
            value: "3 — Inpatient Hospital",
          },
        ],
      },

      EHUB: {
        buttons: [
          {
            id: "ehub",
            label: "View EHUB Screen",
            image: "/smartec-claims/positive/s1_05_ehub_evidence.png",
          },
        ],

        fields: [
          {
            label: "ECN / Claim Number",
            value: "0000090000000101",
          },
          {
            label: "Patient / Insured",
            value: "ZZTEST, SAMPLE THREE",
          },
          {
            label: "Billing Provider NPI",
            value: "1000000021",
          },
          {
            label: "Bill Type",
            value: "111",
          },
          {
            label: "Primary Diagnosis",
            value: "M17.11",
          },
          {
            label: "Dates of Service",
            value: "04/10/2026 – 04/13/2026",
          },
          {
            label: "Total Charge Amount",
            value: "$18,400.00",
          },
          {
            label: "Prior Auth Num",
            value: "AUTH10000001",
          },
        ],
      },

      CGX: {
        buttons: [
          {
            id: "ehub",
            label: "View CGX Screen",
            image: "/smartec-claims/positive/s1_06_cgx_evidence.png",
          },
        ],
        fields: [
          {
            label: "Auth #",
            value: "AUTH10000001",
          },
          {
            label: "Overall Status",
            value: "Approved",
          },
          {
            label: "Total Days Approved",
            value: "3 of 3",
          },
          {
            label: "Approved Service (CPT)",
            value: "27447 — Approved, 1/1 units",
          },
          {
            label: "Facility Provider TIN",
            value: "100000021",
          },
          {
            label: "First Day / Last Day",
            value: "04/10/2026 – 04/13/2026",
          },
          {
            label: "Vendor Supplemental Codes — Diagnosis",
            value: "M17.11 — Approved",
          },
        ],
      },
    },
    Scenario: {
      title: "Authorization Scenario - PCPEND 3F",
      family: "Provider / Contract Validation",
      confidence: 94,
      warnings: [
        {
          severity: "High",
          title: "EDIT : PCPEND 3F",
          description:
            "This claim requires UM Authorization review before processing. An active PCPEND 3F flag has been detected.",
        },
      ],
      rationale:
        "Prior Authorization pending - claim cannot finalize until an authorization is linked.",
      actionNote:
        "This claim is classified as COC Found but Not Applicable because Subscriber Notes contain a COC note, but the current claim does not satisfy the COC applicability conditions. The COC note is approved for a different provider and covers a date range that does not include the current claim DOS.",
    },
    KArecommendation: `Verify the claim type and benefit plan, identify the applicable Date of Service, review UM Inquiry for matching authorization records, validate the latest authorization instructions and Subscriber Notes, and confirm that the authorization applies to the current provider and service period before continuing claim processing.`,
    RCFields: {
      confidence: 94,
      desc: "Link Authorization AUTH10000001 to this claim and resolve edit PCPEND 3F with MPP in control line.",
      recommendation:
        "",

      rationale:
        "Authorization AUTH10000001 is Approved, its dates and approved service fully cover this claim, and the provider/facility match. Recommend entering this authorization on the MPC screen to resolve the PCPEND 3F edit and finalize the claim.",
    },
    Route: {
      impactNote: `No Info`,
      rejectReason: `No Reason`,
      routingNotes: `
- Fields have been reviewed and corrected.
- PCPEND 3F EDIT reviewed.
- Scenario discovery completed.
- Recommendation confidence: 94%.
- No payment instruction was applied.
- No downstream BOT execution was initiated`,
    },
    executionType: "IMAGE",
    executionImages: [
      // "/positive/s1_05_ehub_evidence.png",
      "/smartec-claims/positive/s1_06_cgx_evidence.png",
      "/smartec-claims/positive/s1_cas_initial.png",
      "/smartec-claims/positive/s1_cas_final.png",
    ],
  },
  {
    id: "CLM-C-102943",
    platform: "CAS",
    source: "EDI 837",
    date: "10 Jun 2026 08:45 AM",
    member: "MBR-807801",
    provider: "ZZTEST METHODIST HOSPITAL",
    status: "Ready",
    priority: "Medium",
    show: "yes",
    workspaceType: "SPECIAL",
    validationScreens: {
      CAS: {
        buttons: [
          {
            id: "CAS",
            label: "View CAS Screen",
            image: "/smartec-claims/negative/s2_cas_initial.png",
          },
        ],

        fields: [
          {
            label: "Authorization Number (PRI)",
            value: "PA0000000099, PA0000000100 (2 records — both cancelled)",
          },
          {
            label: "Auth Status (PRI)",
            value: "Cancelled, Cancelled",
          },
          {
            label: "Requested Service (PRI)",
            value: "Revenue Code 0120 (no CPT/HCPCS present)",
          },
          {
            label: "Approved Date Range (PRS)",
            value:
              "PA...099: 07/20–07/22/2026; PA...100: 07/18–07/19/2026 (neither covers claim DOS)",
          },
          {
            label: "Provider on Authorization (PRI)",
            value: "ZZTEST METHODIST HOSPITAL",
          },
          {
            label: "Reviewed By (PRA)",
            value:
              "No active reviewer — PA...099: Cancelled by UR (07/21/2026); PA...100: Cancelled, Duplicate Request (07/17/2026)",
          },
          {
            label: "Provider Tax ID (Claim Record)",
            value: "00-0000031",
          },
          {
            label: "Place of Treatment (POT)",
            value: "1 — Participating Facility",
          },
        ],
      },

      EHUB: {
        buttons: [
          {
            id: "ehub",
            label: "View EHUB Screen",
            image: "/smartec-claims/negative/s2_05_ehub_evidence.png",
          },
        ],

        fields: [
          {
            label: "ECN / Claim Number",
            value: "0000090000000202",
          },
          {
            label: "Patient / Insured",
            value: "ZZTEST, SAMPLE FOUR",
          },
          {
            label: "Billing Provider NPI",
            value: "1000000031",
          },
          {
            label: "Bill Type",
            value: "111",
          },
          {
            label: "Primary Diagnosis",
            value: "A41.9 (plus J96.11, F33.9, K12.2)",
          },
          {
            label: "Dates of Service",
            value: "07/25/2026 – 07/26/2026",
          },
          {
            label: "Total Charge Amount",
            value: "$1,126.00",
          },
          {
            label: "Prior Auth Num",
            value: "Blank",
          },
        ],
      },

      CGX: {
        buttons: [
          {
            id: "ehub",
            label: "View CGX Screen",
            image: "/smartec-claims/negative/s2_06_cgx_evidence.png",
          },
        ],
        fields: [
          {
            label: "Auth #",
            value: "— (none)",
          },
          {
            label: "Overall Status",
            value: "Not Approved",
          },
          {
            label: "Total Days Approved",
            value: "0 of 0",
          },
          {
            label: "Approved Service (CPT)",
            value: "— (none) — Not Approved, 0 units",
          },
          {
            label: "Facility Provider TIN",
            value: "100000031",
          },
          {
            label: "First Day / Last Day",
            value: "07/25/2026 (0 days — does not cover the stay)",
          },
          {
            label: "Vendor Supplemental Codes — Diagnosis",
            value: "A41.9 — Not Approved",
          },
          {
            label: "Review Comments",
            value:
              "Days approved does not match claim — record returned is not usable for this claim (disposition mismatch).",
          },
        ],
      },
    },
    Scenario: {
      title: "Authorization Scenario - PCNOTFND",
      family: "Provider / Contract Validation",
      confidence: 91,
      warnings: [
        {
          severity: "High",
          title: "EDIT : PCNOTFND",
          description:
            "This claim requires UM Authorization review before processing. An active PCNOTFND flag has been detected.",
        },
      ],
      rationale:
        "No Authorization found on file - Claim cannot finalize without a matching approved authorization.",
      actionNote:
        "This claim is classified as COC Found but Not Applicable because Subscriber Notes contain a COC note, but the current claim does not satisfy the COC applicability conditions. The COC note is approved for a different provider and covers a date range that does not include the current claim DOS.",
    },
    KArecommendation: `Verify the claim type and benefit plan, identify the applicable Date of Service, review UM Inquiry for matching authorization records, validate the latest authorization instructions and Subscriber Notes, and confirm that the authorization applies to the current provider and service period before continuing claim processing.`,
    RCFields: {
      confidence: 90,
      desc: "No valid or excepted authorization exists — this cannot be finalized and put 26S in EX field and close the case.",
      recommendation:
        "",

      rationale:
        "No approved authorization matches this claim's Date of Service. Both CAS (PRI) records are cancelled and the CGX record does not cover the stay. The facility is not on the exclusion list and the claim does not qualify for a behavioral-health or timely-filing exception. Recommend routing for further review",
    },
    Route: {
      impactNote: `This claim will be removed from the active execution queue and routed to
        the manual review queue for validation of authorization applicability
        and final payment handling.`,
      rejectReason: `No Reason.`,
      routingNotes: `
- Fields have been reviewed and corrected.
- PCPEND 3F EDIT reviewed.
- Scenario discovery completed.
- Recommendation confidence: 94%.
- No payment instruction was applied.
- No downstream BOT execution was initiated`,
    },

    executionType: "IMAGE",
    executionImages: [
      "/smartec-claims/negative/s2_06_cgx_evidence.png",
      "/smartec-claims/negative/s2_cas_initial.png",
      "/smartec-claims/negative/s2_cas_final.png",
      // "/negative/s2_05_ehub_evidence.png",
    ],
  },
  {
    id: "CLM-T-102944",
    platform: "Facets",
    source: "EDI 837",
    date: "10 Jun 2026 09:45 AM",
    member: "900000001-01",
    provider: "ZZTEST MEDICAL GROUP",
    status: "Ready",
    priority: "Low",
    show: "no",
    workspaceType: "NONE",
    Scenario: {
      title: "Timely Filing Limit Exceeded – Standard Provider",
      family: "Timely Filing",
      confidence: 97,
      warnings: [
        {
          severity: "High",
          title: "WFWM Prov Timely Filing (Ref: WFWM-TF-001)",
          description:
            "No exception category applies; claim pattern matches standard timely filing denial.",
        },
      ],
      rationale:
        "Incorporates TF1, filing-limit violation, provider type, DOS, received date, 510 days, 180-day limit, 330-day excess, no exception, Call-the-Car mismatch, no COB warning, historical pended claims, and SOP reference",
      actionNote:
        "Standard timely filing denial; no exception applies; exceeded by 330 days; WFWM Prov Timely Filing",
    },
    KArecommendation: `Deny line item, uphold TF1; include appeal exception path`,
    RCFields: {
      confidence: 96,
      desc: "Deny Line Item – Uphold TF1 Timely Filing Edit",
      recommendation: "None – no override recommended",

      rationale:
        "510 days after DOS → 180-day limit → 330 days exceeded → no exceptions → no override",
    },
    Route: {
      impactNote:
        "Claim finalized as denied for timely filing; EOB/remittance to reflect provider liability.",

      rejectReason: "TF1 edit upheld; no exception category matched.",

      routingNotes:
        "Auto-Finalize – Deny (No Override Applicable). Routed to Finalization Queue (Denied Claims) by SmarTec Claims Assist (Bot) on 08/06/2026 at 09:15 AM. Final disposition: Denied – Provider liable, $366.00 disallowed. No escalation required.",
    },
    executionType: "NA",
  },
  {
    id: "CLM-T-102945",
    platform: "Facets",
    source: "EDI 837",
    date: "10 Jun 2026 10:11 AM",
    member: "900000002-01",
    provider: "ZZTEST VA CLINIC",
    status: "Ready",
    priority: "Medium",
    show: "no",
    workspaceType: "NONE",
    //     notes: {
    //       coc: {
    //         title: "COC Subscriber Note",
    //         content: `Member has approved COC. Refer to UM # AUTH-4422109.
    // If claim is for services provided by Lovaas Institute, process per UM instructions and the WFWM UM-Auth-Pend workflow.

    // Effective: 02/01/2026 - 08/01/2026`,
    //       },

    //       subscriber: {
    //         title: "Optional General Subscriber Note",
    //         content: `For claims stopped with WFWM UM Auth - PEND, confirm whether provider and DOS match the authorization note before applying COC, ATC, LOA, or other payment instructions. Do not apply authorization payment instruction if provider or service period does not match the current claim.`,
    //       },

    //       um: {
    //         title: "UM Inquiry Clinical Note",
    //         content: `PAY Lovaas Institute per the allowable contracted regional PPO rate per the provider pricing letter. Member remains responsible for applicable copay and/or deductible under the preferred level of benefits. Valid 02/01/2026 through 08/01/2026.`,
    //       },

    //       source: {
    //         title: "Source Comment",
    //         content: `For claims stopped with WFWM UM Auth - PEND, confirm whether provider and DOS match the authorization note before applying COC, ATC, LOA, or other payment instructions. Do not apply authorization payment instruction if provider or service period does not match the current claim.`,
    //       },
    //     },
    Scenario: {
      title: "Timely Filing Exception Granted - VA/DOD Bypass",
      family: "Timely Filing",
      confidence: 95,
      warnings: [
        {
          severity: "High",
          title:
            "WFWM DOD/VA Claim (Ref: WFWM-TF-002) – Exception: No Denial Allowed",
          description:
            "Provider identified as VA Clinic; claim falls within the 6-year VA/DOD filing allowance despite exceeding the standard 180-day limit.",
        },
      ],
      rationale:
        "TF1 flag detected for a claim received 08/02/2026 with a Date of Service of 03/25/2025, resulting in 495 days since service. Although the claim exceeds the standard 180-day provider filing limit by 315 days, the servicing provider is classified as a VA Clinic (Federal / DOD-affiliated) and qualifies for the VA/DOD extended filing allowance of 2,190 days (6 years). The claim is within the extended filing limit with 1,695 days remaining. WFWM DOD/VA Claim (Ref: WFWM-TF-002) applies with no denial allowed. No Call the Car, negative benefit/COB, or historical claims exception is involved.",
      actionNote:
        "This claim is classified as a Timely Filing Violation - VA/DOD Provider Exception because the claim exceeds the standard 180-day filing limit but remains within the applicable 6-year VA/DOD filing allowance. TF1 should be bypassed using the Claim Accept Period / OCA override, and the claim should proceed to standard adjudication. Supervisor concurrence is required and the override action must be logged for audit.",
    },

    KArecommendation: `The claim should not be denied for timely filing. Although the claim was received 495 days after the Date of Service and exceeds the standard 180-day filing limit by 315 days, the servicing provider is a VA Clinic entitled to the 2,190-day VA/DOD filing allowance. The claim remains within the extended filing window with 1,695 days remaining. Therefore, the TF1 edit should be bypassed using the Claim Accept Period / OCA override and the claim should be routed to the Standard Adjudication Queue. If VA/DOD provider status cannot be confirmed on the Indicative tab, route the claim to a Supervisor for manual verification before applying the override.`,

    RCFields: {
      confidence: 94,
      desc: "Override TF1 Edit – Approve via VA/DOD Filing Exception",
      recommendation:
        "Bypass Claim Accept Period (checkbox); Override Claim Accept Months (OCA) selected from dropdown",

      rationale:
        "Claim received 495 days after the Date of Service, which is 315 days beyond the standard 180-day provider filing limit. However, the servicing provider is a VA Clinic entitled to a 6-year (2,190-day) VA/DOD filing allowance. The claim is within the extended filing window with 1,695 days remaining. WFWM DOD/VA Claim SOP applies and specifies that no denial is allowed. Bypass Claim Accept Period should be checked and the Override Claim Accept Months (OCA) option selected. Payment Level should remain In Network with Payment Level Code J1W. Supervisor concurrence is required and the override must be logged for audit.",
    },

    Route: {
      impactNote:
        "Claim released from pend and routed to the Standard Adjudication Queue after the VA/DOD filing exception was confirmed. TF1 was bypassed through the OCA override and the claim was approved for standard adjudication at the contractual allowed amount of $650.00, with a contractual disallow of $241.06. Audit documentation was attached for compliance review.",

      rejectReason:
        "TF1 denial is not applicable because the servicing provider is a confirmed VA Clinic and qualifies for the 2,190-day VA/DOD filing allowance. The claim was received 495 days after the Date of Service, leaving 1,695 days within the applicable extended filing window. The TF1 edit was therefore bypassed using the OCA override.",

      routingNotes: `• Claim queued for Timely Filing review (TF1) on 08/03/2026 at 09:40 AM by examiner_bot01.
• Scenario Discovery identified the VA/DOD provider exception on 08/03/2026 at 11:05 AM.
• VA/DOD 6-year filing exception confirmed.
• TF1 bypassed via OCA override.
• Supervisor override justification reviewed and approved on 08/03/2026 at 11:12 AM by supervisor01.
• Override applied and claim routed to Standard Adjudication Queue.
• Routed by SmarTec Claims Assist (Bot) with Supervisor concurrence at 08/03/2026 11:15 AM.
• Payment Level = In Network.
• Payment Level Code = J1W.
• Bypass Claim Accept Period = Checked.
• Override Claim Accept Months (OCA) selected.
• Allowed amount: $650.00.
• Contractual disallow: $241.06.
• Patient liability: $0.00.
• SLA due date: 08/06/2026.
• Escalation flag: Yes – Supervisor concurrence logged.
• Final disposition: Approved – Paid $650.00.

Required next action:
Proceed with standard adjudication. If VA/DOD provider status cannot be confirmed on the Indicative tab, route to Supervisor for manual verification before applying the override.`,
    },
    executionType: "BOT",
  },
  {
    id: "CLM-A-102946",
    platform: "Facets",
    source: "Paper Claim",
    date: "10 Jun 2026 09:15 AM",
    member: "MBR-915083",
    provider: "Lovaas Institute",
    status: "Ready",
    priority: "High",
    show: "yes",
    workspaceType: "STANDARD",
    formType: "UB04",
    ub04ImageUrl: "/smartec-claims/UB04_scanned.jpg",
    extractedFields: [
      {
        id: "claimId",
        label: "Claim ID",
        value: "CLM-A-102946",
        confidence: 100,
      },

      // {
      //   id: "memberId",
      //   label: "Member ID",
      //   value: "MBR-915083",
      //   confidence: 92,
      // },

      {
        id: "subscriberId",
        label: "Subscriber ID",
        value: "1234567890",
        confidence: 92,
      },

      {
        id: "memberName",
        label: "Member Name",
        value: "Demo Member A",
        confidence: 92,
      },

      {
        id: "providerName",
        label: "Provider Name",
        value: "Lovaas Institute for Early Intervention",
        confidence: 88,
      },

      { id: "npi", label: "Provider NPI", value: "1888776655", confidence: 80 },

      {
        id: "dos",
        label: "DOS",
        value: "05/01/2026 - 05/13/2026",
        confidence: 100,
      },

      { id: "diag1", label: "Diagnosis Code", value: "F84.0", confidence: 85 },

      {
        id: "diag2",
        label: "Diagnosis Description",
        value: "Autistic Disorder",
        confidence: 90,
      },

      {
        id: "cpt",
        label: "CPT Codes",
        value: ["97153HM, 97155HO"],
        confidence: 78,
      },

      {
        id: "totalCharge",
        label: "Total Charge",
        value: "$5,462.50",
        confidence: 98,
      },

      {
        id: "claimSource",
        label: "Claim Source",
        value: "Paper Claim",
        confidence: 98,
      },

      {
        id: "typeOfBill",
        label: "Type of Bill",
        value: "0131",
        confidence: 98,
      },
    ],
    applicationData: [
      // { label: "Member ID", value: "MBR-915083" },
      { label: "Claim ID", value: "CLM-A-102946" },
      { label: "Member Name", value: "Demo Member A" },
      { label: "Facets Status", value: "11 Pended; Awaiting Batch" },
      { label: "Type of Bill", value: "0131" },
      { label: "DOS", value: "05/01/2026 - 05/13/2026" },
      // { label: "Provider ID", value: "PRV-82227002" },
      {
        label: "Provider Name",
        value: "Lovaas Institute for Early Intervention",
      },
      { label: "Provider NPI", value: "1888776655" },
      { label: "Subscriber ID", value: "1234567890" },
      { label: "Member Suffix", value: "00" },
      { label: "Payee", value: "Provider" },
      { label: "Notes Exists", value: "Yes" },
      { label: "Warning", value: "WFWM UM Auth - PEND" },
      { label: "Procedure Codes", value: "97153HM, 97155HO" },
      { label: "Diagnosis", value: "F84.0" },
      { label: "Diagnosis Description", value: "Autistic Disorder" },
      { label: "Total Charge", value: "$5,462.50" },
      { label: "Patient Paid", value: "$0.00" },
      { label: "Auth Required", value: "Yes" },
    ],
    ub04: {
      patientControlNo: "CLM-A-102946",
      medicalRecordNo: "MBR-915083",
      billType: "131",
      subscriberId: "SUB-915083085",
      providerName: "Lovaas Institute for Early Intervention",
      providerAddress: "200 Wellness Ave",
      providerCity: "Los Angeles, CA 90001",

      patientName: "Demo Member A",

      dos: "05/01/2026 - 05/13/2026",
      providerNpi: "1003975236",
      dob: "03/15/2018",
      diagnosisDescription: "Autistic Disorder",
      totalCharge: "$5,462.50",
      diagnosisCode: ["F84.0"],

      serviceLines: [
        {
          date: "05012026",
          revenue: "0450",
          description: "ABA Therapy",
          cpt: "97153HM",
          modifier: "HM",
          units: "4",
          charge: "$2,400.00",
        },
        {
          date: "05032026",
          revenue: "0450",
          description: "ABA Therapy",
          cpt: "97155HO",
          modifier: "HO",
          units: "2",
          charge: "$3,062.50",
        },
      ],
    },
    notes: {
      coc: {
        title: "COC Subscriber Note",
        content: `Member has approved COC. Refer to UM # H24819302. If claim is for services provided by Lovaas Institute, process per UM instructions and the WFWM UM-Auth-Pend workflow. Effective: 02/01/2026 - 08/01/2026.`,
      },

      // subscriber: {
      //   title: "Optional General Subscriber Note",
      //   content: ``,
      // },

      um: {
        title: "UM Inquiry Clinical Note",
        content: `PAY Lovaas Institute per the allowable contracted regional PPO rate per the provider pricing letter. The member is responsible for applicable copay and/or deductible under the preferred level of benefits. Valid 02/01/2026 through 08/01/2026.`,
      },

      // source: {
      //   title: "Source Comment",
      //   content: `Claim image reviewed. Member, provider, diagnosis, procedure code, DOS, and charge values were cross-referenced against Facets pulled data. Key claim fields match. Authorization reference is not available directly on the claim image and will be derived from Subscriber Notes / UM Inquiry.`,
      // },
    },
    Scenario: {
      title: "UM Authorization / COC – Continuity of Care",
      family: "UM Authorization",
      confidence: 94,
      warnings: [
        {
          severity: "High",
          title: "WFWM UM Auth - PEND",
          description:
            "This claim requires UM Authorization review before processing. An active WFWM UM Auth - PEND flag has been detected.",
        },
      ],
      rationale:
        "Active COC note found for Lovaas Institute effective 02/01/2026-08/01/2026. UM Inquiry H24819302 contains payment instruction. Provider and service dates fall within authorized COC period. WFWM UM Auth-PEND workflow applies.",
      
      actionNote:
        "This claim is classified as COC Found but Not Applicable because Subscriber Notes contain a COC note, but the current claim does not satisfy the COC applicability conditions. The COC note is approved for a different provider and covers a date range that does not include the current claim DOS.",
    },
    KArecommendation: `Verify the claim type and benefit plan, identify the applicable Date of Service, review UM Inquiry for matching authorization records, validate the latest authorization instructions and Subscriber Notes, and confirm that the authorization applies to the current provider and service period before continuing claim processing.`,
    RCFields: {
      confidence: 94,
      desc: "Approve COC-Based Pricing and Pay Provider - $4,000.00",
      recommendation:
        "Apply External Price of $2,000.00 to line 1 and $2,200.00 to line 2. Override payment level to In Network; copy member cost-share of $0 deductible, $50 copay and $150 coinsurance; set Payee to Net provider payment: $4,000.00.",

      rationale:
        "COC names Lovaas Institute and covers DOS 05/01/2026-05/13/2026. Provider and dates match. UM Inquiry H24819302 requires contracted regional PPO pricing; $4,200.00 allowed less $200.00 member cost-share results in a $4,000.00 payment.<table style=\"width:100%; border-collapse:collapse; font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#111;\"><thead><tr><th style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:700; background:#ffffff;\">Line</th><th style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:700; background:#ffffff;\">HCPCS / Modifier</th><th style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:700; background:#ffffff;\">Units</th><th style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:700; background:#ffffff;\">Billed Charge</th><th style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:700; background:#ffffff;\">Contract Rate / Unit</th><th style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:700; background:#ffffff;\">Allowed / External Price</th></tr></thead><tbody><tr><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">1</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">97153-HM</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">4</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">$2,400.00</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">$500.00</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">$2,000.00</td></tr><tr><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">2</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">97155-HO</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">2</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">$3,062.50</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">$1,100.00</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left;\">$2,200.00</td></tr><tr><td style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:600;\">Total</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:600;\"></td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:600;\"></td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:600;\">$5,462.50</td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:600;\"></td><td style=\"border:1px solid #000; padding:8px 10px; text-align:left; font-weight:600;\">$4,200.00</td></tr></tbody></table>",
    },
    Route: {
      impactNote: `No Info`,
      rejectReason: `No Reason`,
      routingNotes: `UB-04 and Facets validation completed.
- Low-confidence fields reviewed and corrected.
- WFWM UM Auth - PEND reviewed.
- LOA Notes Reviewed.
- Scenario discovery completed.
- Recommendation confidence: 68% – Manual Review Recommended.
- No payment instruction was applied.
- No downstream BOT execution was initiated`,
    },
    executionType: "BOT",
  },
  {
    id: "CLM-A-102947",
    platform: "Facets",
    source: "Paper Claim",
    date: "10 Jun 2026 09:30 AM",
    member: "MBR-772410",
    provider: "Sunrise Behavioral Therapy",
    status: "Ready",
    priority: "High",
    show: "yes",
    workspaceType: "STANDARD",
    formType: "CMS1500",
    cms1500ImageUrl: "/smartec-claims/CMS_1500.jpg",
    extractedFields: [
      {
        id: "claimId",
        label: "Claim ID",
        value: "CLM-A-102947",
        confidence: 100,
      },

      // {
      //   id: "memberId",
      //   label: "Member ID",
      //   value: "MBR-772410",
      //   confidence: 92,
      // },

      {
        id: "subscriberId",
        label: "Subscriber ID",
        value: "772410999",
        confidence: 92,
      },

      {
        id: "memberName",
        label: "Member Name",
        value: "Member B, Demo",
        confidence: 92,
      },

      {
        id: "providerName",
        label: "Provider Name",
        value: "Sunrise Behavioral Therapy LLC",
        confidence: 88,
      },

      { id: "npi", label: "Provider NPI", value: "1888776655", confidence: 80 },

      {
        id: "dos",
        label: "DOS",
        value: "09/10/2026 - 09/12/2026",
        confidence: 100,
      },

      { id: "diag1", label: "Diagnosis Code", value: "F84.0", confidence: 85 },

      {
        id: "diag2",
        label: "Diagnosis Description",
        value: "Autistic Disorder",
        confidence: 90,
      },

      {
        id: "cpt",
        label: "CPT Codes",
        value: ["97153HM, 97156HO"],
        confidence: 78,
      },

      {
        id: "totalCharge",
        label: "Total Charge",
        value: "$2,150.00",
        confidence: 98,
      },

      {
        id: "claimSource",
        label: "Claim Source",
        value: "Paper Claim",
        confidence: 98,
      },

      {
        id: "claimFormType",
        label: "Claim Form Type",
        value: "CMS-1500 / Professional Claim",
        confidence: 98,
      },
    ],
    applicationData: [
      // { label: "Member ID", value: "MBR-772410" },
      { label: "Member Name", value: "Member B, Demo" },
      // { label: "Facets Claim ID", value: "264293190901" },
      { label: "Facets Status", value: "11 Pended; Awaiting Batch" },
      // { label: "Provider ID", value: "PRV-99887701" },
      { label: "Provider Name", value: "Sunrise Behavioral Therapy LLC" },
      { label: "Provider NPI", value: "1888776655" },
      { label: "Subscriber ID", value: "772410999" },
      { label: "DOS", value: "09/10/2026 - 09/12/2026" },
      { label: "Claim ID", value: "CLM-A-102947" },
      { label: "Diagnosis Description", value: "Autistic Disorder" },
      { label: "Member Suffix", value: "00" },
      { label: "Payee", value: "Provider" },
      { label: "Notes Exists", value: "Yes" },
      { label: "Warning", value: "WFWM UM Auth - PEND" },
      { label: "Procedure Codes", value: "97153HM, 97155HO" },
      { label: "Diagnosis", value: "F84.0" },
      { label: "Total Charge", value: "$2,150.00" },
      { label: "Patient Paid", value: "$0.00" },
      { label: "Auth Required", value: "Yes" },
    ],
    ub04: {
      patientControlNo: "CLM-102939",
      medicalRecordNo: "MBR-772410",
      billType: "131",
      subscriberId: "SUB-772410999",
      providerName: "Sunrise Behavioral Therapy LLC",
      providerAddress: "400 Fitness Ave",
      providerCity: "San Diego, CA 90011",

      patientName: "Member B, Demo",

      dos: "09/10/2026 - 09/12/2026",
      providerNpi: "1888776655",
      dob: "03/15/2018",
      diagnosisDescription: "Autistic Disorder",
      totalCharge: "$2,150.00",
      diagnosisCode: ["F84.0"],

      serviceLines: [
        {
          date: "05012026",
          revenue: "0450",
          description: "ABA Therapy",
          cpt: "97153HM",
          modifier: "HM",
          units: "4",
          charge: "$2,400.00",
        },
        {
          date: "05022026",
          revenue: "0450",
          description: "ABA Therapy",
          cpt: "97156HO",
          modifier: "HO",
          units: "2",
          charge: "$3,062.50",
        },
      ],
    },
    notes: {
      coc: {
        title: "Subscriber Note - LOA",
        content: `Member has approved LOA for services provided by SUNRISE BEHAVIORAL THERAPY LLC. If billing or attending provider is the approved provider, ROUTE CLAIM TO LOA PROCESSOR. If another provider, bypass warning message. LOA information is located in UM # H88213045, LOA # 63140, effective 07/01/2026 - 12/31/2026.`,
      },

      // subscriber: {
      //   title: "Optional General Subscriber Note",
      //   content: ``,
      // },

      // um: {
      //   title: "UM Inquiry Clinical Note",
      //   content: `PAY Lovaas Institute per the allowable contracted regional PPO rate per the provider pricing letter. Member remains responsible for applicable copay and/or deductible under the preferred level of benefits. Valid 02/01/2026 through 08/01/2026.`,
      // },

      // source: {
      //   title: "Source Comment",
      //   content: `For claims stopped with WFWM UM Auth - PEND, confirm whether provider and DOS match the authorization note before applying COC, ATC, LOA, or other payment instructions. Do not apply authorization payment instruction if provider or service period does not match the current claim.`,
      // },
    },
    Scenario: {
      title: "UM Authorization / COC - Mismatch",
      family: "UM Authorization",
      confidence: 91,
      warnings: [
        {
          severity: "High",
          title: "WFWM UM Auth - PEND",
          description:
            "This claim requires UM Authorization review before processing. An active WFWM UM Auth - PEND flag has been detected.",
        },
      ],
      rationale:
        "WFWM UM Auth - PEND flag detected. COC note references Lovaas Institute with effective period 02/01/2026–08/01/2026. Current provider is Sunrise Behavioral Therapy LLC and service dates are 09/10/2026–09/12/2026. Provider and dates do not match COC conditions. Manual review required.",
      actionNote:
        "This claim is classified as COC Found but Not Applicable because Subscriber Notes contain a COC note, but the current claim does not satisfy the COC applicability conditions. The COC note is approved for a different provider and covers a date range that does not include the current claim DOS.",
    },
    KArecommendation: `Validate the claim type, Date of Service, and UM authorization details. Review the latest authorization instructions and Subscriber Notes, and confirm that the authorization applies to the current provider and service period. If the authorization conditions do not match the current claim, do not apply the COC payment instruction and route the claim for manual review.`,
    RCFields: {
      confidence: 68,
      desc: "Route to LOA Processor - Approved Provider Match",
      recommendation:
        "Route claim CLM-102939 to queue CL-COM-LOA OFF Rev with Attachment Description LOA and update the status to Routed - LOA Review. Do not calculate pricing or initiate payment.",

      rationale:
        "LOA 63140 names Sunrise Behavioral Therapy LLC and is effective 07/01/2026-12/31/2026. The claim provider matches and DOS 09/10/2026-09/12/2026 falls within the LOA period. The Subscriber Note explicitly requires routing to the LOA Processor.",
    },
    Route: {
      impactNote: `This claim will be removed from the active execution queue and routed to
        the manual review queue for validation of authorization applicability
        and final payment handling.`,
      rejectReason: `LOA 63140 names Sunrise Behavioral Therapy LLC and is effective 07/01/2026-12/31/2026. The claim provider matches and DOS 09/10/2026-09/12/2026 falls within the LOA period. The Subscriber Note explicitly requires routing to the LOA Processor.`,
      routingNotes: `CMS-1500 and Facets validation completed.
- Low-confidence fields reviewed and corrected.
- WFWM UM Auth - PEND reviewed.
- LOA Notes Reviewed.
- Scenario discovery completed.
- Recommendation confidence: 68% – Manual Review Recommended.
- No payment instruction was applied.
- No downstream BOT execution was initiated.

Required next action:
Review the claim based on the selected condition and destination team.`,
    },
    executionType: "BOT",
  },
  
];
