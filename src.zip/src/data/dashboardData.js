export const kpiCards = [
  {
    title: "Claims Processed",
    value: "1,247",
    change: "+12% vs Yesterday",
    color: "blue",
  },
  {
    title: "Recommendations",
    value: "1,198",
    change: "96.1% Auto Generated",
    color: "green",
  },
  {
    title: "Accepted",
    value: "1,108",
    change: "92.4% Acceptance",
    color: "green",
  },
  {
    title: "Rejected",
    value: "54",
    change: "4.5% Rejected",
    color: "red",
  },
  {
    title: "Escalated",
    value: "36",
    change: "3.0% Routed",
    color: "orange",
  },
  {
    title: "Avg Processing Time",
    value: "3.2m",
    change: "-17% Faster",
    color: "purple",
  },
];

export const metricCards = [
  // {
  //   title: "Average Confidence Score",
  //   value: "94%",
  //   subtitle: "AI Recommendation Confidence",
  //   icon: "🎯",
  // },
  {
    title: "KPI Conditions",
    value: "127",
    subtitle: "Business Rules Evaluated",
    icon: "📊",
  },
  {
    title: "Humans Involved",
    value: "101",
    subtitle: "Manual Review Required",
    icon: "👤",
  },
  {
    title: "Data Sources Queried",
    value: "12",
    subtitle: "Internal + External",
    icon: "🗂️",
  },
  {
    title: "Cases Processed via Downstream BOT",
    value: "1,248",
    subtitle: "Claims completed through approved automated execution",
    icon: "🤖",
  },
];

export const scenarioData = [
  { name: "Authorization", value: 32 },
  { name: "Benefit", value: 24 },
  { name: "Pricing", value: 18 },
  { name: "Clinical", value: 16 },
  { name: "Other", value: 10 },
];

export const trendData = [
  { day: "Mon", processed: 160, accepted: 145, rejected: 9, escalated: 6 },
  { day: "Tue", processed: 175, accepted: 160, rejected: 8, escalated: 7 },
  { day: "Wed", processed: 188, accepted: 170, rejected: 10, escalated: 8 },
  { day: "Thu", processed: 194, accepted: 177, rejected: 9, escalated: 8 },
  { day: "Fri", processed: 215, accepted: 198, rejected: 9, escalated: 8 },
  { day: "Sat", processed: 175, accepted: 160, rejected: 8, escalated: 7 },
  { day: "Sun", processed: 140, accepted: 128, rejected: 6, escalated: 6 },
];

export const platformData = [
  {
    platform: "Facets",
    value: 56,
  },
  {
    platform: "HRP",
    value: 29,
  },
  {
    platform: "Other",
    value: 15,
  },
];