import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { ClaimProvider } from "./context/ClaimContext";
import { Toaster } from "react-hot-toast";
import App from "./App";

import "./styles/global.css";
import "./styles/sidebar.css";
import "./styles/header.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter basename="/smartec-claims">
    <ClaimProvider>
      <Toaster
      position="bottom-right"
      reverseOrder={false}
      toastOptions={{
        duration: 2500,
        style: {
          background: "#fff",
          color: "#111827",
          border: "1px solid #DCFCE7",
          borderRadius: "10px",
          boxShadow: "0 8px 24px rgba(0,0,0,.15)"
        },
        success: {
          iconTheme: {
            primary: "#22C55E",
            secondary: "#fff",
          },
        },
      }}
    />
      <App />
    </ClaimProvider>
    </BrowserRouter>
  </React.StrictMode>
);