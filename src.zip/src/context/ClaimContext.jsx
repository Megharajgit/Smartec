import { createContext, useContext, useState } from "react";
import { claims as initialClaims } from "../data/claimsData";

const ClaimContext = createContext();



export function ClaimProvider({ children }) {
  const [selectedClaim, setSelectedClaim] = useState(null);
  const [maxUnlockedStage, setMaxUnlockedStage] = useState(0);
  const [workflowType, setWorkflowType] = useState("approve");
  const [claims, setClaims] = useState(initialClaims);

  return (
    <ClaimContext.Provider
      value={{
        claims,
        setClaims,
        selectedClaim,
        setSelectedClaim,
        maxUnlockedStage,
        setMaxUnlockedStage,
        workflowType,
        setWorkflowType,
      }}
    >
      {children}
    </ClaimContext.Provider>
  );
}

export function useClaim() {
  return useContext(ClaimContext);
}