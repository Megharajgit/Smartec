import { useRef, useState } from "react";
import "../styles/recommendationRejectedCard.css";

export default function RecommendationRejectedCard({ claim }) {
  const fileInputRef = useRef(null);

  const [files, setFiles] = useState([]);

  const [reason, setReason] = useState(claim.Route.rejectReason);

  const [priority, setPriority] = useState("High");

  const [condition, setCondition] = useState("");

  const [dueDate, setDueDate] = useState("");
  const handleBrowse = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (e) => {
    const selected = Array.from(e.target.files);

    setFiles((prev) => [...prev, ...selected]);
  };

  const removeFile = (index) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="rejected-card">
      <h2>Rationale for Rejecting Recommendation</h2>

      
      <textarea
        ref={(el) => {
          if (el) {
            el.style.height = "auto";
            el.style.height = `${el.scrollHeight}px`;
          }
        }}
        value={reason}
        onChange={(e) => {
          setReason(e.target.value);
          e.target.style.height = "auto";
          e.target.style.height = `${e.target.scrollHeight}px`;
        }}
        className="rejection-textarea"
      />

      <label>Standard Conditions (Optional)</label>

      <select value={condition} onChange={(e) => setCondition(e.target.value)}>
        <option value="">Select a standard condition</option>

        <option>Medical Record Missing</option>

        <option>Additional Authorization Review Required</option>

        <option>Provider Information Clarification Required</option>

        <option>Benefit Validation Required</option>

        <option>Clinical Review Required</option>

        <option>Princing Review Required</option>
      </select>

     

      <div className="bottom-row">
       
      </div>
    </div>
  );
}
