import { useState } from "react";
import "../styles/casEhubCgxValidation.css";
import { useNavigate } from "react-router-dom";

// Groups consecutive "important" fields into one bordered block, and leaves
// regular fields standing alone — mirrors how the reference panel wraps a
// contiguous run of highlighted rows (Provider Name → CPT Codes) in a single box.
function groupFields(fields) {
  const groups = [];

  fields.forEach((field) => {
    const last = groups[groups.length - 1];

    if (field.important && last?.important) {
      last.items.push(field);
    } else {
      groups.push({ important: !!field.important, items: [field] });
    }
  });

  return groups;
}

function ValidationField({ field, index }) {
  return (
    <div className="validation-system-field" key={`${field.label}-${index}`}>
      <div className="validation-field-label">
        <span>{field.label}</span>
      </div>

      <div className="validation-field-value">
        <span className="validation-field-value-pill">{field.value}</span>
      </div>
    </div>
  );
}

function ValidationCard({ title, data, onScreenSelect }) {
  if (!data) {
    return null;
  }

  const fields = data.fields || [];

  // Remove empty / NA fields
  const visibleFields = fields.filter(
    (field) =>
      field.value !== null &&
      field.value !== undefined &&
      field.value !== "" &&
      String(field.value).toLowerCase() !== "na",
  );

  const fieldGroups = groupFields(visibleFields);

  return (
    <div className="validation-system-card">
      {/* Card Header */}
      <div className="validation-system-header">
        <div className="validation-system-title">{title}</div>

        {data.buttons?.length > 0 && (
          <div className="validation-system-actions">
            {data.buttons.map((button) => (
              <button
                key={button.id}
                className="system-action-button"
                onClick={() => onScreenSelect(button)}
              >
                {button.label}
              </button>
            ))}
          </div>
        )}

        {data.button && (
          <button className="system-action-button view-button">
            {data.button}
          </button>
        )}
      </div>

      {/* Fields */}
      <div className="validation-system-fields">
        {fieldGroups.length > 0 ? (
          fieldGroups.map((group, gIndex) =>
            group.important ? (
              <div
                className="validation-field-group is-important"
                key={`group-${gIndex}`}
              >
                {group.items.map((field, index) => (
                  <ValidationField
                    field={field}
                    index={index}
                    key={`${field.label}-${index}`}
                  />
                ))}
              </div>
            ) : (
              group.items.map((field, index) => (
                <ValidationField
                  field={field}
                  index={index}
                  key={`${field.label}-${index}`}
                />
              ))
            ),
          )
        ) : (
          <div className="validation-system-empty">
            No information available
          </div>
        )}
      </div>
    </div>
  );
}

export default function CasEhubCgxValidation({ claim }) {
  const navigate = useNavigate();
  const [selectedScreen, setSelectedScreen] = useState(null);
  const [showComments, setShowComments] = useState(false);

  const screens = claim?.validationScreens;

  if (!screens) {
    return (
      <div className="validation-system-empty-page">
        <h2>No Validation Information Available</h2>
        <p>
          Validation information for CAS, EHUB and CGX is not currently
          available for this claim.
        </p>
      </div>
    );
  }

  const availableScreens = ["CAS", "EHUB", "CGX"].filter(
    (screen) => screens[screen],
  );

  return (
    <div className="validation-system-page">
      <div className="validation-system-page-header">
        <div>
          <h2>Validation Workspace</h2>
          <p>Cross-system validation details</p>
        </div>
      </div>

      <div className={`validation-system-grid grid-${availableScreens.length}`}>
        {availableScreens.map((screen) => (
          <ValidationCard
            key={screen}
            title={screen}
            data={screens[screen]}
            onScreenSelect={setSelectedScreen}
          />
        ))}
      </div>

      <div className="validation-footer-actions">
        <button
          className="comments-btn"
          onClick={() => setShowComments(true)}
        >
          <svg
            width="15"
            height="15"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" />
          </svg>
          Comments
        </button>

        <button
          className="scenario-next-btn"
          onClick={() => navigate(`/scenario-discovery/${claim.id}`)}
        >
          Scenario Discovery →
        </button>
      </div>

      {/* ================= COMMENTS MODAL ================= */}

      {showComments && (
        <div
          className="comments-modal-overlay"
          onClick={() => setShowComments(false)}
        >
          <div
            className="comments-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="comments-modal-header">
              <h3>Comments</h3>

              <button
                className="comments-modal-close"
                onClick={() => setShowComments(false)}
              >
                ×
              </button>
            </div>

            <div className="comments-modal-body">
              <p>No comments found</p>
            </div>
          </div>
        </div>
      )}

      {/* ================= SCREEN VIEWER ================= */}

      {selectedScreen && (
        <div className="screen-viewer-overlay">
          <div className="screen-viewer">
            <div className="screen-viewer-header">
              <div>
                <h3>{selectedScreen.label} Screen</h3>
                <span>CAS system view</span>
              </div>

              <button
                className="screen-viewer-close"
                onClick={() => setSelectedScreen(null)}
              >
                ×
              </button>
            </div>

            <div className="screen-viewer-body">
              <img
                src={selectedScreen.image}
                alt={`${selectedScreen.label} screen`}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
