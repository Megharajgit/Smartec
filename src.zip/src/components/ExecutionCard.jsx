import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { RiCheckLine, RiLoader4Line } from "react-icons/ri";
import "../styles/executionCard.css";
import { useClaim } from "../context/ClaimContext";

export default function ExecutionCard({ claim }) {
  const navigate = useNavigate();
  const { setMaxUnlockedStage, claims, setClaims } = useClaim();
  const [showImageTheater, setShowImageTheater] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [zoom, setZoom] = useState(1);
  const imageWrapperRef = useRef(null);

  const [executing, setExecuting] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [showProgressModal, setShowProgressModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  // Marks the claim as processed and surfaces the same success modal used
  // for the API-execution path — shared by both completion routes so the
  // image-gallery flow ends the same way the fetch call does.
  const completeExecution = () => {
    setClaims((prev) =>
      prev.map((c) => (c.id === claim.id ? { ...c, status: "PROCESSED" } : c)),
    );
    setCompleted(true);
    setExecuting(false);
    setShowSuccessModal(true);
  };

  // Every new image starts scrolled to the top and fitted to the viewer,
  // instead of inheriting the previous image's scroll position or zoom.
  // Deliberately does NOT depend on isPaused, so pausing/resuming mid-scroll
  // doesn't reset the image back to the top.
  useEffect(() => {
    if (!showImageTheater) {
      return;
    }

    if (imageWrapperRef.current) {
      imageWrapperRef.current.scrollTop = 0;
    }

    setZoom(1);
  }, [currentImageIndex, showImageTheater]);

  // Auto-play: scroll each image from top to bottom (if it's taller than
  // the viewer) so the whole screenshot is actually seen, THEN advance to
  // the next one — rather than jumping to the next image after a flat
  // timer while most of a tall screenshot was never shown.
  useEffect(() => {
    if (!showImageTheater || isPaused || !claim?.executionImages?.length) {
      return;
    }

    const wrapper = imageWrapperRef.current;
    const isLastImage = currentImageIndex >= claim.executionImages.length - 1;

    let cancelled = false;
    let rafId = null;
    let holdTimer = null;

    const advance = () => {
      if (cancelled) {
        return;
      }

      if (isLastImage) {
        // Reached the end of the slideshow — close the gallery
        // automatically and complete execution, same as the API path.
        setShowImageTheater(false);
        setCurrentImageIndex(0);
        setIsPaused(false);
        setZoom(1);
        completeExecution();
        return;
      }

      setCurrentImageIndex((prev) => prev + 1);
    };

    // Small delay to let the browser finish laying out the image before
    // we measure how much (if anything) there is to scroll.
    const startDelay = setTimeout(() => {
      if (cancelled || !wrapper) {
        holdTimer = setTimeout(advance, 1600);
        return;
      }

      const maxScroll = wrapper.scrollHeight - wrapper.clientHeight;
      const startPos = wrapper.scrollTop;
      const remaining = maxScroll - startPos;

      if (remaining <= 4) {
        // Nothing left to scroll (whole image already fits/was shown) —
        // just hold on it briefly so it registers, then move on.
        holdTimer = setTimeout(advance, 1600);
        return;
      }

      // Scroll speed scales with how far there is to go, clamped to a
      // sensible range so a very tall image doesn't take forever and a
      // barely-overflowing one doesn't blink past.
      const duration = Math.min(3200, Math.max(1200, remaining * 1.2));
      const start = performance.now();

      const step = (now) => {
        if (cancelled) {
          return;
        }

        const elapsed = now - start;
        const progress = Math.min(1, elapsed / duration);
        const eased =
          progress < 0.5
            ? 2 * progress * progress
            : 1 - Math.pow(-2 * progress + 2, 2) / 2;

        wrapper.scrollTop = startPos + remaining * eased;

        if (progress < 1) {
          rafId = requestAnimationFrame(step);
        } else {
          holdTimer = setTimeout(advance, 500);
        }
      };

      rafId = requestAnimationFrame(step);
    }, 300);

    return () => {
      cancelled = true;
      clearTimeout(startDelay);
      if (holdTimer) clearTimeout(holdTimer);
      if (rafId) cancelAnimationFrame(rafId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showImageTheater, isPaused, currentImageIndex, claim?.executionImages]);

  // const approvedAction = "Process Claim per COC UM Payment Instruction";
  const approvedAction = "Process Claim on recommended Instruction";

  //--------------------------------------------------
  // Execute Bot
  //--------------------------------------------------

  const executeClaim = async () => {
    if (claim.executionType === "IMAGE") {
      setExecuting(true);
      setCompleted(false);
      setCurrentImageIndex(0);
      setIsPaused(false);
      setZoom(1);
      setShowImageTheater(true);
      return;
    }

    try {
      setExecuting(true);
      setCompleted(false);
      setShowProgressModal(true);

      const response = await fetch("http://localhost:5000/execute-bot", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          claimId: claim.id,
        }),
      });

      setShowProgressModal(false);
      completeExecution();
    } catch (error) {
      console.error(error);

      setShowProgressModal(false);

      alert(error.message || "Unable to execute claim.");
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="execution-page">
      <div className="execution-card">
        <h2>Execute Approved Action</h2>

        <div className="execution-summary">
          <div className="summary-row">
            <span>Claim ID</span>
            <strong>{claim.id}</strong>
          </div>

          <div className="summary-row">
            <span>Approved Action</span>
            <strong className="approved-action">{approvedAction}</strong>
          </div>
        </div>

        <button
          className="execute-btn"
          disabled={executing || completed}
          onClick={executeClaim}
        >
          {completed ? "Completed" : executing ? "Executing..." : "Execute"}
        </button>
      </div>

      <div className="execution-actions">
        <button
          className="return-btn"
          onClick={() => navigate("/claim-inventory")}
        >
          Return to Claim Directory
        </button>

        <button
          className="dashboard-btn"
          onClick={() => navigate("/dashboard")}
        >
          View Dashboard
        </button>
      </div>

      {/* ===========================================
            Progress Modal
      =========================================== */}

      {showProgressModal && (
        <div className="modal-overlay">
          <div className="progress-modal">
            <RiLoader4Line size={70} className="spinner" />

            <h3>Executing Automation...</h3>

            <p>Please wait for downstream to complete...</p>
          </div>
        </div>
      )}

      {/* ===========================================
            Success Modal
      =========================================== */}

      {showSuccessModal && (
        <div className="modal-overlay">
          <div className="success-modal">
            <div className="success-icon">
              <RiCheckLine />
            </div>

            <h2>Claim Processed Successfully</h2>

            <p>
              Claim <strong>{claim.id}</strong> has been processed successfully.
            </p>

            <button
              className="success-btn"
              onClick={() => setShowSuccessModal(false)}
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ===========================================
            THEATER SCREEN
      ===============================================*/}
      {showImageTheater && claim?.executionImages?.length > 0 && (
        <div className="image-theater-overlay">
          <div className="image-theater">
            {/* Header */}
            <div className="theater-header">
              <div>
                <h3>{claim.title || "Execution Preview"}</h3>
                <span>Automated execution preview</span>
              </div>

              <button
                className="theater-close"
                onClick={() => {
                  setShowImageTheater(false);
                  setCurrentImageIndex(0);
                  setIsPaused(false);
                  setZoom(1);
                }}
              >
                ×
              </button>
            </div>

            {/* Image area */}
            <div className="theater-viewer">
              <button
                className="theater-nav theater-prev"
                disabled={claim.executionImages.length <= 1}
                onClick={() =>
                  setCurrentImageIndex((prev) =>
                    prev === 0 ? claim.executionImages.length - 1 : prev - 1,
                  )
                }
              >
                ‹
              </button>

              <div className="theater-image-wrapper" ref={imageWrapperRef}>
                <img
                  key={currentImageIndex}
                  src={claim.executionImages[currentImageIndex]}
                  alt={`Execution step ${currentImageIndex + 1}`}
                  className={`theater-image ${zoom > 1 ? "zoomed" : ""}`}
                  style={{
                    transform: `scale(${zoom})`,
                    transformOrigin: "top center",
                  }}
                  onDoubleClick={() => {
                    setZoom((prev) => (prev === 1 ? 2 : 1));
                  }}
                />
              </div>

              <button
                className="theater-nav theater-next"
                disabled={claim.executionImages.length <= 1}
                onClick={() =>
                  setCurrentImageIndex((prev) =>
                    prev === claim.executionImages.length - 1 ? 0 : prev + 1,
                  )
                }
              >
                ›
              </button>
            </div>

            {/* Footer */}
            <div className="theater-footer">
              <div className="theater-progress">
                <span>Step {currentImageIndex + 1}</span>

                <span className="progress-separator">/</span>

                <span>{claim.executionImages.length}</span>
              </div>

              <div className="theater-dots">
                {claim.executionImages.map((_, index) => (
                  <button
                    key={index}
                    className={`theater-dot ${
                      index === currentImageIndex ? "active" : ""
                    }`}
                    onClick={() => setCurrentImageIndex(index)}
                  />
                ))}
              </div>

              <div className="theater-buttons">
                <button
                  className="theater-button"
                  onClick={() =>
                    setCurrentImageIndex((prev) => (prev === 0 ? 0 : prev - 1))
                  }
                >
                  Previous
                </button>

                <button
                  className="theater-button"
                  onClick={() => setIsPaused((prev) => !prev)}
                >
                  {isPaused ? "Resume" : "Pause"}
                </button>

                <button
                  className="theater-button primary"
                  onClick={() =>
                    setCurrentImageIndex((prev) =>
                      Math.min(prev + 1, claim.executionImages.length - 1),
                    )
                  }
                >
                  Next
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
