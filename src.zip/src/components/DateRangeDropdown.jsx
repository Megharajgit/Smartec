import "./../styles/dateRangeDropdown.css";

const options = [
  "Today",
  "Last 7 Days",
  "Last 30 Days",
  "Custom",
];

export default function DateRangeDropdown({
  selected,
  onSelect,
}) {
  return (
    <div className="date-dropdown">

      {options.map((item) => (
        <div
          key={item}
          className={`date-option ${
            selected === item ? "active" : ""
          }`}
          onClick={() => onSelect(item)}
        >
          {item}
        </div>
      ))}

    </div>
  );
}