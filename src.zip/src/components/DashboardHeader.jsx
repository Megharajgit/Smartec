import "../styles/dashboardHeader.css";

export default function DashboardHeader() {
  return (
    <div className="dashboard-header">

      <div>

        <h1 style={{fontSize:"18px"}}>
          Leadership Dashboard
        </h1>

        <p>
          AI Claims Assistant operational insights and performance metrics
        </p>

      </div>

    </div>
  );
}