import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";

import { scenarioData } from "../data/dashboardData";
import "../styles/scenarioChart.css";

const COLORS = ["#2563EB", "#16A34A", "#F59E0B", "#DC2626", "#8B5CF6"];

export default function ScenarioChart() {
  return (
    <div className="chart-card">
      <h3>Scenario Distribution</h3>

      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={scenarioData}
            dataKey="value"
            innerRadius={70}
            outerRadius={110}
            paddingAngle={3}
            animationDuration={1200}
          >
            {scenarioData.map((entry, index) => (
              <Cell key={index} fill={COLORS[index]} />
            ))}
          </Pie>

          <Tooltip />
        </PieChart>
      </ResponsiveContainer>

      <div className="chart-legend">
        {scenarioData.map((item, index) => (
          <div key={item.name} className="legend-row">
            <span
              className="legend-dot"
              style={{
                background: COLORS[index],
              }}
            />

            {item.name}

            <strong>{item.value}%</strong>
          </div>
        ))}
      </div>
    </div>
  );
}
