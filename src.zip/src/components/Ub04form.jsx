const UB04_FIELDS = [
  { id: "patCntlNo",         label: "Pat. Cntl #",          top: 1.2,  left: 60,  width: 13, height: 1.6 },
  { id: "medRecNo",          label: "Medical Record #",     top: 3.3,  left: 60,  width: 13, height: 1.6 },
  { id: "typeOfBill",        label: "Type of Bill",         top: 3.2,  left: 91,  width: 6,  height: 1.6 },
  { id: "statementPeriod",   label: "Statement Period",     top: 7.3,  left: 71,  width: 27, height: 2.0 },
  { id: "payToProviderName", label: "Provider Name",        top: 2.8,  left: 28,  width: 21, height: 2.0 },
  { id: "patientName",       label: "Patient Name",         top: 11.1, left: 3,   width: 25, height: 2.3 },
  { id: "patientAddress",    label: "Patient Address",      top: 11.0, left: 35,  width: 23, height: 2.3 },
  { id: "birthdate",         label: "Birthdate",            top: 16.5, left: 2,   width: 8,  height: 2.3 },
  { id: "sex",               label: "Sex",                  top: 16.5, left: 11,  width: 4,  height: 2.3 },
  { id: "revCode1",          label: "Rev Code (row 1)",     top: 34.0, left: 2,   width: 6,  height: 2.0 },
  { id: "description1",      label: "Description (row 1)",  top: 33.6, left: 9,   width: 25, height: 2.3 },
  { id: "hcpcs1",            label: "HCPCS (row 1)",        top: 34.3, left: 34,  width: 7,  height: 1.8 },
  { id: "servDate1",         label: "Serv. Date (row 1)",   top: 33.6, left: 52,  width: 9,  height: 2.0 },
  { id: "units1",            label: "Units (row 1)",        top: 34.3, left: 64,  width: 4,  height: 1.6 },
  { id: "totalCharges1",     label: "Total Charges (row 1)",top: 33.5, left: 73,  width: 8,  height: 2.0 },
  { id: "revCode2",          label: "Rev Code (row 2)",     top: 36.5, left: 2,   width: 6,  height: 2.0 },
  { id: "description2",      label: "Description (row 2)",  top: 36.0, left: 9,   width: 25, height: 2.3 },
  { id: "hcpcs2",            label: "HCPCS (row 2)",        top: 36.8, left: 34,  width: 7,  height: 1.6 },
  { id: "servDate2",         label: "Serv. Date (row 2)",   top: 36.0, left: 52,  width: 9,  height: 2.0 },
  { id: "units2",            label: "Units (row 2)",        top: 36.8, left: 64,  width: 4,  height: 1.6 },
  { id: "totalCharges2",     label: "Total Charges (row 2)",top: 36.6, left: 73,  width: 8,  height: 1.8 },
  { id: "totals",            label: "Totals",               top: 65.5, left: 73,  width: 10, height: 2.3 },
  { id: "payerName",         label: "Payer Name",           top: 69.5, left: 3,   width: 20, height: 2.2 },
  { id: "insuredsName",      label: "Insured's Name",       top: 73.5, left: 3,   width: 20, height: 2.2 },
  { id: "insuredsUniqueId",  label: "Insured's Unique ID",  top: 73.5, left: 36,  width: 15, height: 2.2 },
  { id: "groupName",         label: "Group Name",           top: 72.6, left: 58,  width: 15, height: 2.2 },
  { id: "treatmentAuthCode", label: "Treatment Auth Codes", top: 77.0, left: 2,   width: 20, height: 2.2 },
  { id: "principalDx",       label: "Principal Dx",         top: 78.5, left: 0.5, width: 10, height: 2.8 },
  { id: "attendingNpi",      label: "Attending NPI",        top: 84.5, left: 73,  width: 10, height: 1.8 },
  { id: "remarks",           label: "Remarks",              top: 90.5, left: 2,   width: 45, height: 7.5 },
];

// One extracted-field id -> exactly one image field (no shared/colliding targets)
const EXTRACTED_TO_IMAGE_ID = {
  claimId: ["patCntlNo"],
  memberId: ["medRecNo"],
  subscriberId: ["insuredsUniqueId"],
  memberName: ["patientName"],
  providerName: ["payToProviderName"],
  npi: ["attendingNpi"],
  dos: ["statementPeriod"],
  diag1: ["principalDx"],
  diag2: ["principalDx"],
  cpt: ["hcpcs1", "hcpcs2"],
  totalCharge: ["totals"],
  typeOfBill: ["typeOfBill"],
};

function resolveImageIds(ids) {
  const resolved = new Set();
  ids.forEach((id) => {
    (EXTRACTED_TO_IMAGE_ID[id] || []).forEach((imgId) => resolved.add(imgId));
  });
  return resolved;
}

export default function UB04Form({
  claim,
  highlightedFields = [],
  editedFields = {},
}) {
  const highlightedImageIds = resolveImageIds(highlightedFields);
  const editedImageIds = resolveImageIds(Object.keys(editedFields));

  return (
    <div className="form-image-container">
      <img src={claim.ub04ImageUrl} alt="UB-04 Claim Form" draggable={false} />

      <div className="field-overlay-layer">
        {UB04_FIELDS.map((field) => {
          const isHighlighted = highlightedImageIds.has(field.id);
          const isEdited = editedImageIds.has(field.id);
          const cls = [
            "field-box",
            isHighlighted && "field-highlighted",
            isEdited && "field-edited",
          ]
            .filter(Boolean)
            .join(" ");

          return (
            <div
              key={field.id}
              className={cls}
              style={{
                top: `${field.top}%`,
                left: `${field.left}%`,
                width: `${field.width}%`,
                height: `${field.height}%`,
              }}
            >
              {(isHighlighted || isEdited) && (
                <span className="field-label-tag">{field.label}</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}