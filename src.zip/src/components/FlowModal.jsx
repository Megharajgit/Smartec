import { createPortal } from "react-dom";
import { RiCloseLine } from "react-icons/ri";
import "../styles/flowModal.css";

export default function FlowModal({
    open,
    onClose
}) {

    if (!open) return null;

    return createPortal(

        <div
            className="manual-overlay"
            onClick={onClose}
        >

            <div
                className="manual-modal"
                onClick={(e) => e.stopPropagation()}
            >

                <div className="manual-header">

                    <div className="manual-title">
                        📄 Flow Chart
                    </div>

                    <button
                        className="close-btn-sop"
                        onClick={onClose}
                    >
                        <RiCloseLine size={22}/>
                    </button>

                </div>

                <div className="pdf-container">

                    <iframe
                        src="/smartec-claims/UMAuthPend_Complete_Flowchart.pdf"
                        title="Flow Chart"
                        className="pdf-frame"
                    />

                </div>

            </div>

        </div>,

        document.body

    );

}