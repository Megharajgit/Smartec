import { useState } from "react";
import "../styles/routingSummaryCard.css";

export default function RoutingSummaryCard({ claim, selectedTeam }) {
  const [notes, setNotes] = useState(claim.Route.routingNotes);
  return (
    <div className="routing-summary-card">
      <h2 style={{ fontWeight: "600", fontSize: "1.5em", color: "#344054" }}>
        Routing Notes Summary
      </h2>
      <textarea
        ref={(el) => {
          if (el) {
            el.style.height = "auto";
            el.style.height = `${el.scrollHeight}px`;
          }
        }}
        value={notes}
        onChange={(e) => {
          setNotes(e.target.value);
          e.target.style.height = "auto";
          e.target.style.height = `${e.target.scrollHeight}px`;
        }}
        placeholder="Add routing notes for the team..."
      ></textarea>
     
    </div>
  );
}
