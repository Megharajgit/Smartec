import { RiCloseLine } from "react-icons/ri";
import "./../styles/notesModal.css";

export default function NotesModal({
    open,
    onClose,
    notes,
}) {

    if (!open) return null;

    const colors = {
        coc: "blue",
        subscriber: "orange",
        um: "green",
        source: "purple",
    };

    return (
        <div className="notes-overlay">

            <div className="notes-modal">

                <div className="notes-header">

                    <h2>Comments & Notes</h2>

                    <RiCloseLine
                        onClick={onClose}
                        className="close-icon"
                    />

                </div>

                <div className="notes-body">

                    {Object.entries(notes).map(([key, note]) => (

                        <div
                            key={key}
                            className={`note-card ${colors[key]}`}
                        >

                            <div className="note-heading">

                                {note.title}

                            </div>

                            <div className="note-text">

                                {note.content}

                            </div>

                        </div>

                    ))}

                </div>

            </div>

        </div>
    );
}