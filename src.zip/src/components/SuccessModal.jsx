import "../styles/successModal.css";

export default function SuccessModal({
    open,
    title,
    message,
    buttonText = "Close",
    onClose,
}) {

    if (!open) return null;

    return (

        <div className="modal-overlay">

            <div className="success-modal">

                <div className="success-icon">
                    ✓
                </div>

                <h2>{title}</h2>

                <p>{message}</p>

                <button
                    className="success-btn"
                    onClick={onClose}
                >
                    {buttonText}
                </button>

            </div>

        </div>

    );

}