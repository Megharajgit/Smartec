import "../styles/kpiCard.css";
import { kpiCards } from "../data/dashboardData";

export default function KPICard() {
  return (
    <div className="kpi-grid">
      {kpiCards.map((item) => (
        <div key={item.title} className="kpi-card">
          <div className="kpi-title">{item.title}</div>

          <div className="kpi-value">{item.value}</div>

          <div className={`kpi-change ${item.color}`}>{item.change}</div>
        </div>
      ))}
    </div>
  );
}
