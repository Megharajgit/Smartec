import {
  RiQuestionLine,
  RiNotification3Line,
  RiHistoryLine,
  RiSettings3Line,
  RiArrowDownSLine,
} from "react-icons/ri";
import { FcGoogle } from "react-icons/fc";
import "./../styles/header.css";
import { useState } from "react";
import NotificationDropdown from "./NotificationDropdown";
import AutomationAgentStatus from "./AutomationAgentStatus";
import ProfileDropdown from "./ProfileDropdown";

export default function Header() {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  return (
    <>
      {/* TOP HEADER */}

      {/* SECOND HEADER */}
      <div className="sub-header">
        <div className="page-name">
          <h2>SmarTec Claims</h2>
        </div>
        <AutomationAgentStatus />
        <div className="user-section">
          <div
            className="icon-wrapper notification"
            onClick={() => setShowNotifications(!showNotifications)}
          >
            <RiNotification3Line />

            {/* <span className="badge-count">0</span> */}

            {showNotifications && <NotificationDropdown />}
          </div>

          <div className="profile" onClick={() => setShowProfile(!showProfile)}>
            <div className="avatar">JD</div>

            <div>
              <div className="user-name">John Doe</div>

              <div className="user-role">Claims Processor</div>
            </div>

            <RiArrowDownSLine className="profile-arrow" />

            {showProfile && <ProfileDropdown />}
          </div>
        </div>
      </div>
    </>
  );
}
