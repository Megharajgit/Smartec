import { useState } from "react";
import "../styles/knowledgeAssetsCard.css";

import SOPModal from "./SOPModal";
import FlowModal from "./FlowModal";

const articles = [
  {
    title: "UM Authorization Research SOP",
    type: "SOP",
    color: "blue",
    link: "/smartec-claims/ManualSOP.pdf",
  },
  {
    title: "Medical Claim Authorization Review",
    type: "Policy",
    color: "purple",
    link: "/smartec-claims/ManualSOP.pdf",
  },
  {
    title: "UM Inquiry Services",
    type: "Pricing",
    color: "green",
    link: "/smartec-claims/ManualSOP.pdf",
  },
  {
    title: "Current Authorization Instructions",
    type: "Manual",
    color: "gray",
    link: "/smartec-claims/PCNOTFND_Authorization_Denied_or_Not_Found.pdf",
  },
  {
    title: "Prospective UM Fallback",
    type: "SOP",
    color: "orange",
    link: "/smartec-claims/ManualSOP.pdf",
  },
  {
    title: "Subscriber Notes / COC Note Review",
    type: "SOP",
    color: "blue",
    link: "/smartec-claims/ManualSOP.pdf",
  },
];

export default function KnowledgeAssetsCard({ claim }) {
  const [showSOP, setShowSOP] = useState(false);
  const [showFlow, setShowFlow] = useState(false);

  return (
    <>
      <div className="knowledge-card">
        <div className="knowledge-header">
          <h2>📖 Auto-Pulled Knowledge Assets</h2>

          <p>Relevant assets for Authorization Scenario — OON</p>
        </div>

        {/* ARTICLES */}
        <div className="asset-card">
          <h3 className="section-title">Knowledge Articles</h3>

          {articles.map((article) => (
            <div key={article.title} className="article-row">
              <a
                href={article.link}
                target="_blank"
                rel="noopener noreferrer"
                className="article-title"
              >
                • {article.title}
              </a>

              <span className={`article-tag ${article.color}`}>
                {article.type}
              </span>
            </div>
          ))}
        </div>
        {/* SOP */}

        <div className="asset-card">
          <div className="asset-top">
            <div>
              <small>Smart SOP</small>

              <h4>OON Validation SOP v1.2</h4>
            </div>

            <span className="asset-status">Active</span>
          </div>

          <button className="asset-link" onClick={() => setShowSOP(true)}>
            ↗ View SOP
          </button>
        </div>

        {/* FLOW */}

        <div className="asset-card">
          <div className="asset-top">
            <div>
              <small>Process Flow</small>

              <h4>Auth Validation Flow v1.3</h4>
            </div>

            <span className="asset-status">Active</span>
          </div>

          <button className="asset-link" onClick={() => setShowFlow(true)}>
            ↗ View Flow
          </button>
        </div>
        {/* CHECKLIST */}

      </div>

      <SOPModal open={showSOP} onClose={() => setShowSOP(false)} />
      <FlowModal open={showFlow} onClose={() => setShowFlow(false)} />
    </>
  );
}
