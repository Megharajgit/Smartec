const CMS1500_FIELDS = [
  { id: "insuredsIdNumber",  label: "Insured's ID Number",     top: 11.5, left: 59,  width: 12, height: 1.5 },
  { id: "patientName",       label: "Patient's Name",          top: 14.5, left: 3.5, width: 13, height: 1.8 },
  { id: "patientDobSex",     label: "Patient's DOB / Sex",     top: 14.8, left: 36,  width: 20, height: 2.0 },
  { id: "insuredsName",      label: "Insured's Name",          top: 14.6, left: 60,  width: 16, height: 1.8 },
  { id: "patientAddress",    label: "Patient's Address",       top: 17.6, left: 3,   width: 30, height: 7.5 },
  { id: "insuredsAddress",   label: "Insured's Address",       top: 17.6, left: 59,  width: 30, height: 7.5 },
  { id: "insuredsPolicyGrp", label: "Insured's Policy/Group #",top: 27.2, left: 60,  width: 20, height: 1.8 },
  { id: "diagnosis1",        label: "Diagnosis 1",             top: 60.3, left: 5,   width: 20, height: 1.6 },
  { id: "dosLine1",          label: "Date of Service (row 1)", top: 66.5, left: 3,   width: 27, height: 3.3 },
  { id: "cpt1",              label: "CPT/HCPCS (row 1)",       top: 66.5, left: 30,  width: 12, height: 3.3 },
  { id: "dosLine2",          label: "Date of Service (row 2)", top: 69.8, left: 3,   width: 27, height: 3.3 },
  { id: "cpt2",              label: "CPT/HCPCS (row 2)",       top: 69.8, left: 30,  width: 12, height: 3.3 },
  { id: "federalTaxId",      label: "Federal Tax ID",          top: 79.9, left: 4,   width: 15, height: 1.6 },
  { id: "patientsAcctNo",    label: "Patient's Account No.",   top: 80.6, left: 30,  width: 18, height: 1.6 },
  { id: "totalCharge",       label: "Total Charge",            top: 80.6, left: 59,  width: 12, height: 1.6 },
  { id: "balanceDue",        label: "Balance Due",             top: 80.6, left: 87,  width: 12, height: 1.6 },
  { id: "providerNameOnly",  label: "Provider Name",           top: 84.1, left: 60,  width: 36, height: 1.4 },
  { id: "providerNpiOnly",   label: "Provider NPI",            top: 90.8, left: 60,  width: 20, height: 1.7 },
];

const EXTRACTED_TO_IMAGE_ID = {
  claimId: ["patientsAcctNo"],
  memberId: [], // no distinct box on CMS1500 — 1a is the subscriber/insured ID only
  subscriberId: ["insuredsIdNumber"],
  memberName: ["patientName"],
  providerName: ["providerNameOnly"],
  npi: ["providerNpiOnly"],
  dos: ["dosLine1", "dosLine2"],
  diag1: ["diagnosis1"],
  diag2: ["diagnosis1"],
  cpt: ["cpt1", "cpt2"],
  totalCharge: ["totalCharge"],
};

function resolveImageIds(ids) {
  const resolved = new Set();
  ids.forEach((id) => {
    (EXTRACTED_TO_IMAGE_ID[id] || []).forEach((imgId) => resolved.add(imgId));
  });
  return resolved;
}

export default function CMS1500Form({
  claim,
  highlightedFields = [],
  editedFields = {},
}) {
  const highlightedImageIds = resolveImageIds(highlightedFields);
  const editedImageIds = resolveImageIds(Object.keys(editedFields));

  return (
    <div className="form-image-container">
      <img src={claim.cms1500ImageUrl} alt="CMS-1500 Claim Form" draggable={false} />

      <div className="field-overlay-layer">
        {CMS1500_FIELDS.map((field) => {
          const isHighlighted = highlightedImageIds.has(field.id);
          const isEdited = editedImageIds.has(field.id);
          const cls = [
            "field-box",
            isHighlighted && "field-highlighted",
            isEdited && "field-edited",
          ]
            .filter(Boolean)
            .join(" ");

          return (
            <div
              key={field.id}
              className={cls}
              style={{
                top: `${field.top}%`,
                left: `${field.left}%`,
                width: `${field.width}%`,
                height: `${field.height}%`,
              }}
            >
              {(isHighlighted || isEdited) && (
                <span className="field-label-tag">{field.label}</span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}