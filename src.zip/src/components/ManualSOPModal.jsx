import { createPortal } from "react-dom";
import { RiCloseLine } from "react-icons/ri";
import "../styles/manualSOPModal.css";

export default function ManualSOPModal({
    open,
    onClose
}) {

    if (!open) return null;

    return createPortal(

        <div
            className="manual-overlay"
            onClick={onClose}
        >

            <div
                className="manual-modal"
                onClick={(e) => e.stopPropagation()}
            >

                <div className="manual-header">

                    <div className="manual-title">
                        📄 Manual SOP
                    </div>

                    <button
                        className="close-btn-sop"
                        onClick={onClose}
                    >
                        <RiCloseLine size={22}/>
                    </button>

                </div>

                <div className="pdf-container">

                    <iframe
                        src="/smartec-claims/PCNOTFND_Authorization_Denied_or_Not_Found.pdf"
                        title="Manual SOP"
                        className="pdf-frame"
                    />

                </div>

            </div>

        </div>,

        document.body

    );

}