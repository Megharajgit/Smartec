import "../styles/metricCards.css";
import { metricCards } from "../data/dashboardData";

export default function MetricCards() {
  return (
    <div className="metric-grid">
      {metricCards.map((item) => (
        <div key={item.title} className="metric-card">
          <div className="metric-icon">{item.icon}</div>

          <div className="metric-content">
            <div className="metric-value">{item.value}</div>

            <div className="metric-title">{item.title}</div>

            <div className="metric-subtitle">{item.subtitle}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
