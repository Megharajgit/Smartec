import {
  RiMenu2Line,
  RiFileList2Line,
  RiSearchLine,
  RiStackLine,
  RiFlashlightLine,
  RiSendPlaneLine,
  RiBarChart2Line,
  RiBook2Line,
  RiArrowLeftSLine,
} from "react-icons/ri";
import SagilityLogo from "../assets/sagility.logo.png";
import "./../styles/sidebar.css";
import { useState } from "react";
import { useLocation, Link, useNavigate } from "react-router-dom";
import { useClaim } from "../context/ClaimContext";

const menus = [
  {
    title: "Claim Inventory",
    path: "/claim-inventory",
    icon: <RiMenu2Line />,
  },
  {
    title: "Validation Workspace",
    path: "/validation-workspace",
    icon: <RiFileList2Line />,
  },
  {
    title: "Scenario Discovery",
    path: "/scenario-discovery",
    icon: <RiSearchLine />,
  },
  {
    title: "Recommendation Workspace",
    path: "/recommendation-workspace",
    icon: <RiStackLine />,
  },
  {
    title: "Execution",
    path: "/execution",
    icon: <RiFlashlightLine />,
  },
  {
    title: "Route",
    path: "/route",
    icon: <RiSendPlaneLine />,
  },
];
const utilityMenus = [
  {
    title: "Dashboard",
    path: "/dashboard",
    icon: <RiBarChart2Line />,
  },
];

export default function Sidebar() {
  const { selectedClaim, maxUnlockedStage, workflowType } = useClaim();
  const location = useLocation();
  const navigate = useNavigate();

  const [collapsed, setCollapsed] = useState(false);
  return (
    <aside className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <div className="logo-area">
        <div className="logo-box">
          <img
            src={SagilityLogo}
            alt="Sagility"
            style={{
              height: 28,
              width: "auto",
            }}
          />
        </div>

        {!collapsed && (
          <div>
            <div className="brand-title">SmarTec</div>

            <div className="brand-subtitle">Claims Assist</div>
          </div>
        )}
      </div>

      <div className="menu-list">
        {/* Workflow */}
        {menus.map((item, index) => {
          const active = location.pathname.startsWith(item.path);

          let disabled = index > maxUnlockedStage;
          // Disable Execution if rejection workflow
          if (workflowType === "reject" && item.path === "/execution") {
            disabled = true;
          }

          // Disable Route until execution if approval workflow
          if (workflowType === "approve" && item.path === "/route") {
            disabled = true;
          }

          const targetPath =
            selectedClaim && item.path !== "/claim-inventory"
              ? `${item.path}/${selectedClaim.id}`
              : item.path;

          return (
            <Link
              key={item.title}
              to={disabled ? "#" : targetPath}
              onClick={(e) => {
                if (disabled) e.preventDefault();
              }}
              className={`${active ? "menu-item active" : "menu-item"} ${disabled ? "disabled" : ""
                }`}
            >
              <span className="icon">{item.icon}</span>

              {!collapsed && <span className="title">{item.title}</span>}

              {active && !collapsed && <span className="active-dot" />}
            </Link>
          );
        })}

        {/* Utilities */}
        {utilityMenus.map((item) => {
          const active = location.pathname.startsWith(item.path);

          return (
            <Link
              key={item.title}
              to={item.path}
              className={active ? "menu-item active" : "menu-item"}
            >
              <span className="icon">{item.icon}</span>

              {!collapsed && <span className="title">{item.title}</span>}

              {active && !collapsed && <span className="active-dot" />}
            </Link>
          );
        })}
      </div>
      <div className="sidebar-bottom">
        <div className="menu-item">
          <span className="icon">
            <RiBook2Line />
          </span>

          {!collapsed && (
            <span
              className="title"
              onClick={() => navigate("/knowledge-repository")}
            >
              Knowledge Repository
            </span>
          )}
        </div>

        <div
          className="menu-item"
          onClick={() => setCollapsed(!collapsed)}
          style={{ cursor: "pointer" }}
        >
          <span className="icon">{collapsed ? "▶" : <RiArrowLeftSLine />}</span>

          {!collapsed && <span className="title">Collapse</span>}
        </div>
      </div>
    </aside>
  );
}
