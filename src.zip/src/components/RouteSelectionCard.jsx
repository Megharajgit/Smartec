import "../styles/routeSelectionCard.css";

const teams = [
  {
    id: 1,
    title: "LOA Team",
    description: "LOA notes, eligibility, provider status, coverage rules.",
    subtitle: "Validate manual LOA  eligibility",
    assigned: "Sarah Wilson",
    reason: "LOA Rule",
  },

  {
    id: 2,
    title: "Benefits Team",
    description:
      "Reviews member benefits, eligibility, provider status, policy.",
    subtitle: "Resolve manual review needed",
    assigned: "Alex Smith",
    reason: "Pricing Rule",
  },

  {
    id: 3,
    title: "Clinical Review Team",
    description: "Reviews notes, clinical records.",
    subtitle: "Clinical review needed",
    assigned: "John Carter",
    reason: "Clinical Review",
  },

  {
    id: 4,
    title: "Authorization Team",
    description: "Escalate to further review.",
    subtitle: "Escalate - needs supervision",
    assigned: "Manager",
    reason: "Escalation",
  },
];

export default function RouteSelectionCard({
  selectedTeam,
  claim,
  setSelectedTeam,
}) {
  return (
    <div className="route-selection-card">
      <h2 style={{ fontWeight: "600", fontSize: "1.5em", color: "#344054" }}>
        Route Claim To
      </h2>
      <p>
        This claim will be routed to one of the following for further action.
      </p>
      {teams.map((team) => (
        <div
          key={team.id}
          className={`team-card ${
            selectedTeam.team === team.title ? "active" : ""
          }`}
          onClick={() =>
            setSelectedTeam({
              team: team.title,

              assignedTo: team.assigned,

              reason: team.reason,
            })
          }
        >
          <div className="radio">
            <div className="dot" />
          </div>

          <div>
            <h3>{team.title}</h3>

            <p>{team.description}</p>

            <small>{team.subtitle}</small>
          </div>
        </div>
      ))}

    </div>
  );
}
