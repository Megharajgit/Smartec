import "./../styles/notification.css";

export default function NotificationDropdown() {
  return (
    <div className="notification-dropdown">

      <div className="notification-header">
        Notifications
      </div>
      <div className="notification-item">
        <span className="dot"></span>
        <span>No new notification as of now!, check after some time</span>
      </div>

    </div>
  );
}