import "../styles/platformChart.css";
import { platformData } from "../data/dashboardData";

export default function PlatformChart() {
  return (
    <div className="chart-card">
      <h3>Platform Mix</h3>

      {platformData.map((item) => (
        <div className="platform-row" key={item.platform}>
          <div className="platform-top">
            <span>{item.platform}</span>

            <strong>{item.value}%</strong>
          </div>

          <div className="progress">
            <div
              className="progress-fill"
              style={{
                width: `${item.value}%`,
              }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}
