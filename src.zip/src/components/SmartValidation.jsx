import { useNavigate } from "react-router-dom";
import "../styles/smartValidation.css";

const fieldMap = {
  "Claim ID":["claimId"],
  "Member ID": ["memberId"],
  "Member Name": ["memberName"],
  "Facets Status": [],
  "Type of Bill": ["typeOfBill"],
  // "Provider ID": ["providerId"],
  "Provider Name": ["providerName"],
  "Provider NPI": ["npi"],
  "Subscriber ID": ["subscriberId"],
  "DOS":["dos"],
  "Member Suffix": [],
  "Payee": [],
  "Notes Exists": [],
  "Warning": [],
  "Procedure Codes": ["cpt"],
  "Diagnosis": ["diag1"],
  "Diagnosis Description": ["diag2"],
  "Total Charge": ["totalCharge"],
  "Patient Paid": [],
  "Auth Required": [],
  "Facets Claim ID": ["claimId"],
};

function Field({ ids = [], value, highlightedFields = [] }) {
  const isActive = ids.some((id) => highlightedFields.includes(id));
  return (
    <div className={`field ${isActive ? "active" : ""}`}>
      {Array.isArray(value) ? value.join(", ") : value}
    </div>
  );
}

export default function SmartValidation({
  claim,
  editMode,
  setEditMode,
  approved,
  setApproved,
  highlightedFields,
}) {
  const navigate = useNavigate();

  return (
    <div className="validation-card">
      <div className="validation-header">
        <h3>Application Data — Facets</h3>
        <span className="readonly-tag">Read-only</span>
      </div>

      <div className="application-body">
        {(claim.applicationData || []).map((item) => (
          <div key={item.label} className="application-row">
            <span className="application-label">{item.label}</span>
            <div className="application-value">
              <Field
                ids={fieldMap[item.label] || []}
                value={item.value}
                highlightedFields={highlightedFields}
              />
            </div>
          </div>
        ))}
      </div>

      <div className="validation-footer">
      </div>
    </div>
  );
}