import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";

import { trendData } from "../data/dashboardData";
import "../styles/trendChart.css";

export default function TrendChart() {
  return (
    <div className="chart-card">
      <h3>Processing Trend (Last 7 Days)</h3>

      <ResponsiveContainer width="100%" height={245}>
        <LineChart
          data={trendData}
          margin={{
            top: 5,
            right: 10,
            left: -15,
            bottom: 0,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" />

          <XAxis
            dataKey="day"
            tick={{ fontSize: 11 }}
            tickMargin={4}
          />

          <YAxis
            tick={{ fontSize: 11 }}
            width={28}
          />

          <Tooltip />

          <Line
            dataKey="processed"
            stroke="#2563EB"
            strokeWidth={2.5}
            dot={false}
          />

          <Line
            dataKey="accepted"
            stroke="#16A34A"
            strokeWidth={2.5}
            dot={false}
          />

          <Line
            dataKey="rejected"
            stroke="#DC2626"
            strokeWidth={2.5}
            dot={false}
          />

          <Line
            dataKey="escalated"
            stroke="#F59E0B"
            strokeWidth={2.5}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}