import { useEffect, useState } from "react";
import {
//   RiCheckCircleLine,
  RiErrorWarningLine,
  RiLoader4Line,
} from "react-icons/ri";

import "../styles/automationAgentStatus.css";

const AGENT_URL = "http://localhost:5000";

export default function AutomationAgentStatus() {
  const [status, setStatus] = useState("checking");
  const [agentInfo, setAgentInfo] = useState(null);
const [installStarted, setInstallStarted] = useState(false);

  const checkAgent = async () => {
    try {
      const response = await fetch(`${AGENT_URL}/health`, {
        method: "GET",
      });

      if (!response.ok) {
        throw new Error("Agent unavailable");
      }

      const data = await response.json();

      if (data.status === "ok") {
        setStatus("connected");
        setAgentInfo(data);
      } else {
        setStatus("disconnected");
      }
    } catch (error) {
      setStatus("disconnected");
      setAgentInfo(null);
    }
  };

  useEffect(() => {
    checkAgent();

    const interval = setInterval(() => {
      checkAgent();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  if (status === "checking") {
    return (
      <div className="agent-status checking">
        <RiLoader4Line className="agent-spinner" />
        <span>Checking Agent...</span>
      </div>
    );
  }

  if (status === "connected") {
    return (
      <div className="agent-status connected">
        {/* <RiCheckCircleLine /> */}

        <div className="agent-status-text">
          <span>Automation Agent</span>
          <strong>Connected</strong>
        </div>
      </div>
    );
  }

  return (
    <div className="agent-status disconnected">
      <RiErrorWarningLine />

      <div className="agent-status-text">
        <span>Automation Agent</span>
        <strong>Not Connected</strong>
      </div>
      {/* <button
  className="install-agent-btn"
  onClick={() => {
    const link = document.createElement("a");

    link.href = "/utils/SmarTecAutomationAgent.exe";
    link.download = "SmarTecAutomationAgent.exe";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }}
>
  Install Automation Agent
</button> */}
<button
  className="install-agent-btn"
  onClick={() => {
    const link = document.createElement("a");
    link.href = "/smartec-claims/utils/SmarTecAutomationAgent.exe";
    link.download = "SmarTecAutomationAgent.exe";

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setInstallStarted(true);
  }}
>
  Install Automation Agent
</button>
{installStarted && status !== "connected" && (
  <div className="agent-modal-overlay">
    <div className="agent-modal">
      <h2>Automation Agent Installation</h2>

      <div className="agent-steps">
        <div>✅ Download completed?</div>
        <div>📂 Open SmarTecAutomationAgent.exe</div>
        <div>🛡️ If Windows displays a warning, click "More Info" → "Run Anyway"</div>
        <div>⏳ Waiting for Agent to start...</div>
      </div>

      <div className="agent-loader">
        <RiLoader4Line className="agent-spinner" />
      </div>

      <p>
        This window will automatically close once the Automation Agent is
        detected.
      </p>
    </div>
  </div>
)}
    </div>
  );
}