import { useNavigate, useParams } from "react-router-dom";
import "../styles/recommendationCard.css";

export default function RecommendationCard({ claim, onApprove, onReject }) {
  const navigate = useNavigate();
  const confidence = claim.RCFields.confidence;
  const rec_desc = claim.RCFields.desc;

  const color =
    confidence >= 90 ? "#16a34a" : confidence >= 75 ? "#f59e0b" : "#dc2626";

  const degrees = confidence * 3.6;

  const highConfidence = confidence >= 90;

  return (
    <div className="recommend-card-new">
      {/* Recommendation */}

      <div
        className={`recommendation-banner ${highConfidence ? "high" : "low"}`}
      >

        <div
          className="circle"
          style={{
            background: `conic-gradient(
            ${color} ${degrees}deg,
            #f1f5f9 ${degrees}deg
        )`,
          }}
        >
          <div className="circle-inner">{confidence}%</div>
        </div>

        <div className="banner-content">
          <span className="banner-tag">
            {highConfidence
              ? "High Confidence"
              : "Low Confidence – Manual Review Recommended"}
          </span>

          <h2>
              {rec_desc}
          </h2>

          <p>{claim.RCFields.recommendation}</p>
        </div>
      </div>

      {/* Rationale */}

      <div className="rationale-card">
        <h3>Rationale</h3>

        <div
          className="rationale-text"
          dangerouslySetInnerHTML={{ __html: claim.RCFields.rationale }}
        />
      </div>

      {/* Buttons */}

      <div className="recommend-actions">
        {highConfidence ? (
          <div style={{width:"100%",display:"flex",gap:"10px"}}>
          <button className="approve-btn" onClick={onApprove}>
            Approve for Execution
          </button>
          <button className="reject-btn" onClick={onReject}>
            Manual Route
          </button>
          </div>
        ) : (
          <button className="reject-btn" onClick={onReject}>
            Manual Route
          </button>
        )}

        <button className="back-btn" onClick={() => navigate(-1)}>
          ← Back to Scenario Discovery
        </button>
      </div>
    </div>
  );
}
