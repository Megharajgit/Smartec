import {
  RiZoomInLine,
  RiZoomOutLine,
  RiRefreshLine,
  RiArrowLeftSLine,
  RiArrowRightSLine,
  RiFileTextLine,
  RiArrowDownSLine,
} from "react-icons/ri";

import "../styles/sourceDocuments.css";
import UB04Form from "./Ub04form";
import CMS1500Form from "./CMS1500Form";
import { useState } from "react";
import NotesModal from "./NotesModal";
export default function SourceDocuments({
  highlightedFields,
  editedFields,
  claim,
}) {
  const [activeTab, setActiveTab] = useState("source");
  const [showNotesModal, setShowNotesModal] = useState(false);
  const [zoom, setZoom] = useState(0.9);
  const notes = claim?.notes || {};
  const currentNote = notes[activeTab];
  const FormComponent = claim?.formType === "CMS1500" ? CMS1500Form : UB04Form;

  return (
    <div className="source-card">
      {/* ================= Header ================= */}

      <div className="source-header">
        <h3>Source Documents</h3>

        <div className="header-icons">
          <div className="source-toolbar">
            <button
              className="zoom-btn"
              onClick={() => setZoom((z) => Math.max(0.5, z - 0.05))}
            >
              <RiZoomOutLine />
            </button>

            <span className="zoom-text">{Math.round(zoom * 100)}%</span>

            <button
              className="zoom-btn"
              onClick={() => setZoom((z) => Math.min(1.2, z + 0.05))}
            >
              <RiZoomInLine />
            </button>
          </div>
          {/* <RiRefreshLine /> */}
        </div>
      </div>

      {/* ================= UB04 ================= */}

      <div className="document-viewer">
        <div className="document-wrapper">
          <div
            className="document-scale"
            style={{ "--zoom": zoom }}
            onWheel={(e) => {
              if (!e.ctrlKey) return;

              e.preventDefault();

              setZoom((z) =>
                Math.min(1.2, Math.max(0.5, z + (e.deltaY < 0 ? 0.05 : -0.05))),
              );
            }}
          >
            <FormComponent
              claim={claim}
              highlightedFields={highlightedFields}
              editedFields={editedFields}
            />
          </div>
        </div>
      </div>

      {/* ================= Footer ================= */}

      <div className="document-footer">
        <button
          className="comments-btn"
          onClick={() => setShowNotesModal(true)}
        >
          💬 Comments ({Object.keys(notes).length})
        </button>
      </div>

      <NotesModal
        open={showNotesModal}
        onClose={() => setShowNotesModal(false)}
        notes={notes}
      />
    </div>
  );
}
