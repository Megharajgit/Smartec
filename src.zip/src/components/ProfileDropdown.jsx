import "./../styles/profileDropdown.css";

export default function ProfileDropdown() {
  return (
    <div className="profile-dropdown">

      <div className="profile-item signout">
        Sign Out
      </div>

    </div>
  );
}