import { useState, useRef, useEffect } from "react";
import "../styles/extractedClaimData.css";
import { useNavigate } from "react-router-dom";
import { useClaim } from "../context/ClaimContext";
import toast from "react-hot-toast";

function getColor(score) {
  if (score >= 90) return "green";
  if (score >= 75) return "yellow";
  return "red";
}

export default function ExtractedClaimData({
  claim,
  editMode,
  highlightedFields,
  setHighlightedFields,
  editedFields,
  setEditedFields,
  approved,
  setApproved,
}) {
  const bodyRef = useRef(null);
  const [editor, setEditor] = useState({
    open: false,
    field: null,
    value: "",
    top: 0,
  });
  const { setMaxUnlockedStage } = useClaim();
  const navigate = useNavigate();

  useEffect(() => {
    setMaxUnlockedStage(1);
  }, [setMaxUnlockedStage]);

  const updateValue = (id, value) => {
    setEditedFields((prev) => ({
      ...prev,
      [id]: value,
    }));

    if (!highlightedFields.includes(id)) {
      setHighlightedFields((prev) => [...prev, id]);
    }
  };

  return (
    <div className="extract-card">
      <div className="extract-header">
        <h3>Extracted Claim Data</h3>

        <div className="edit-info">
          ℹ️
          <span className="edit-tooltip">
            Double-click a field to edit its value.
          </span>
        </div>
      </div>

      <div className="extract-body" ref={bodyRef}>
        {(claim.extractedFields || []).map((field) => {
          const color = getColor(field.confidence);
          const currentValue = editedFields[field.id] ?? field.value;

          return (
            <div
              key={field.id}
              className={`extract-row
${field.confidence < 90 ? "editable" : ""}
${highlightedFields.includes(field.id) ? "corrected" : ""}
`}
            >
              <div
                className="field-label"
                onClick={() => setHighlightedFields([field.id])}
              >
                {field.label}
              </div>

              <div
                className="field-value-wrapper"
                onDoubleClick={(e) => {
                  const row = e.currentTarget.closest(".extract-row");

                  setEditor({
                    open: true,
                    field,
                    value: currentValue,
                    top: row.offsetTop - bodyRef.current.scrollTop,
                  });
                  setHighlightedFields([field.id]);
                }}
              >
                <div className="value-text" title={currentValue}>
                  {currentValue}
                  {field.confidence < 90 && (
                    <span className="edit-hint">✎</span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {editor.open && (
        <div
          className="floating-editor"
          style={{
            top: editor.top,
          }}
        >
          <div className="editor-title">Edit {editor.field.label}</div>

          <textarea
            autoFocus
            value={editor.value}
            onChange={(e) => {
              setEditor((prev) => ({
                ...prev,
                value: e.target.value,
              }));
            }}
          />

          <div className="editor-actions">
            <button
              className="cancel-edit"
              onClick={() => {
                setEditor({
                  open: false,
                  field: null,
                  value: "",
                  top: 0,
                });
              }}
            >
              Cancel
            </button>

            <button
              className="save-edit"
              onClick={() => {
                updateValue(editor.field.id, editor.value);
                toast.success(`${editor.field.label} updated successfully.`);
                setEditor({
                  open: false,
                  field: null,
                  value: "",
                  top: 0,
                });
              }}
            >
              ✓
            </button>
          </div>
        </div>
      )}

      <div className="validation-footer">
        <button
          className={`footer-btn ${approved ? "approved" : ""}`}
          disabled={approved}
          onClick={() => setApproved(true)}
        >
          {approved ? "✓ Extracted Data Approved" : "Approve Extracted Data"}
        </button>

        <button
          className={`footer-btn ${approved ? "proceed" : "disabled"}`}
          disabled={!approved}
          onClick={() => navigate(`/scenario-discovery/${claim.id}`)}
        >
          Proceed to Scenario Discovery →
        </button>
      </div>
    </div>
  );
}
