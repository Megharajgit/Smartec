import "./../styles/filterDropdown.css";

export default function FilterDropdown({
  items,
  selected,
  onSelect,
  width = 170,
  maxHeight = 260,
}) {
  return (
    <div
      className="filter-dropdown"
      style={{
        width,
        maxHeight,
        overflowY: items.length > 5 ? "auto" : "hidden",
      }}
    >
      {items.map((item) => (
        <div
          key={item}
          className={
            selected === item
              ? "filter-item active"
              : "filter-item"
          }
          onClick={() => onSelect(item)}
        >
          {item}
        </div>
      ))}
    </div>
  );
}