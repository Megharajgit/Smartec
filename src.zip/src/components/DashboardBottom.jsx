import "../styles/dashboardBottom.css";

export default function DashboardBottom() {
  return (
    <div className="dashboard-bottom">
      {/* LEFT */}

      <div className="bottom-card recent-card">
        <h3>Recent Claim Outcomes</h3>

        <table className="recent-table">
          <thead>
            <tr>
              <th>Claim ID</th>
              <th>Platform</th>
              <th>Primary Scenario</th>
              <th>AI Recommendation</th>
              <th>Status</th>
              <th>Avg. Time</th>
            </tr>
          </thead>

          <tbody>
            <tr>
              <td className="link">CLM-103938</td>
              <td>Facets</td>
              <td>Authorization Required</td>
              <td>Approve with Auth Exception OON-...</td>
              <td>
                <span className="status success">Accepted</span>
              </td>
              <td>4.3 min</td>
            </tr>

            <tr>
              <td className="link">CLM-103931</td>
              <td>HRP</td>
              <td>Authorization Required</td>
              <td>Request Auth</td>
              <td>
                <span className="status pending">Pending</span>
              </td>
              <td>5.1 min</td>
            </tr>

            <tr>
              <td className="link">CLM-103929</td>
              <td>Facets</td>
              <td>Authorization Scenario</td>
              <td>Approve for Reprocessing</td>
              <td>
                <span className="status success">Accepted</span>
              </td>
              <td>3.2 min</td>
            </tr>

            <tr>
              <td className="link">CLM-103940</td>
              <td>Facets</td>
              <td>Clinical Review</td>
              <td>Refer for Clinical Review</td>
              <td>
                <span className="status routed">Routed</span>
              </td>
              <td>5.7 min</td>
            </tr>
          </tbody>
        </table>

        <button className="view-link">View Detailed Impact Report →</button>
      </div>

      {/* RIGHT */}

      <div className="bottom-card impact-card">
        <h3>Business Impact Summary (Today)</h3>

        <div className="impact-row">
          <span>Average Handling Time</span>

          <div className="impact-value">
            <strong className="green">3.2 min</strong>

            <small>-17% vs Yesterday</small>
          </div>
        </div>

        <div className="impact-row">
          <span>Application Queued</span>

          <div className="impact-value">
            <strong className="blue">4</strong>

            <small>Workqueue: 4 + BBQ Lots</small>
          </div>
        </div>

        <div className="impact-row">
          <span>Human Decisions</span>

          <div className="impact-value">
            <strong className="blue">101</strong>

            <small>Manual Reviews: 101</small>
          </div>
        </div>

        <div className="impact-row">
          <span>Claims Routed Risk</span>

          <div className="impact-value">
            <strong className="orange">14</strong>

            <small>Adverse Routing: 14</small>
          </div>
        </div>

        <div className="impact-row">
          <span>Data Sources Queried</span>

          <div className="impact-value">
            <strong className="green">12</strong>

            <small>12 sources avg</small>
          </div>
        </div>

        <button className="view-link">View Detailed Impact Report →</button>
      </div>
    </div>
  );
}
