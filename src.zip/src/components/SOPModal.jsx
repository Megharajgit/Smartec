import React, { useEffect, useMemo, useState } from "react";
import * as XLSX from "xlsx";
import "../styles/sopModal.css";
import {
  RiCloseLine,
  RiSearchLine,
  RiFileExcel2Line,
  RiArrowLeftSLine,
  RiArrowRightSLine,
  RiZoomInLine,
  RiZoomOutLine,
} from "react-icons/ri";

export default function SOPModal({ open, onClose }) {
  const [workbook, setWorkbook] = useState(null);

  const [sheetNames, setSheetNames] = useState([]);

  const [activeSheet, setActiveSheet] = useState("");

  const [rows, setRows] = useState([]);

  const [search, setSearch] = useState("");

  const [zoom, setZoom] = useState(0.9);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");
  useEffect(() => {
    if (!open) return;

    loadWorkbook();
  }, [open]);
  async function loadWorkbook() {
    try {
      setLoading(true);

      const response = await fetch("/smartec-claims/SOP.xlsx");

      const arrayBuffer = await response.arrayBuffer();

      const wb = XLSX.read(arrayBuffer, {
        type: "array",
      });

      setWorkbook(wb);

      setSheetNames(wb.SheetNames);

      setActiveSheet(wb.SheetNames[0]);
    } catch (e) {
      console.log(e);

      setError("Unable to load workbook.");
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    if (!workbook) return;

    const sheet = workbook.Sheets[activeSheet];

    const data = XLSX.utils.sheet_to_json(sheet, {
      header: 1,

      defval: "",
    });

    setRows(data);
  }, [workbook, activeSheet]);
  const filteredRows = useMemo(() => {
    if (search === "") return rows;

    return rows.filter((row) => {
      return row.some((cell) => {
        return String(cell).toLowerCase().includes(search.toLowerCase());
      });
    });
  }, [rows, search]);
  if (!open) return null;

  return (
    <div className="sop-overlay">
      <div className="sop-modal">
        {/* ================= HEADER ================= */}

        <div className="sop-header">
          <div className="left">
            <RiFileExcel2Line size={22} />

            <div>
              <div className="title">Standard Operating Procedure</div>

              <div className="subtitle">{activeSheet}</div>
            </div>
          </div>

          <div className="right">
            <div className="search-box">
              <RiSearchLine />

              <input
                placeholder="Search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <button onClick={() => setZoom((z) => Math.max(0.5, z - 0.1))}>
              <RiZoomOutLine />
            </button>

            <span>{Math.round(zoom * 100)}%</span>

            <button onClick={() => setZoom((z) => Math.min(1.5, z + 0.1))}>
              <RiZoomInLine />
            </button>

            <button className="close-btn" onClick={onClose}>
              <RiCloseLine />
            </button>
          </div>
        </div>
        <div className="sop-body">
          {/* LEFT PANEL */}

          <div className="sheet-panel">
            <div className="sheet-panel-header">
              <RiFileExcel2Line size={18} />
              <span>Workbook Sheets</span>

              <div className="sheet-count">{sheetNames.length}</div>
            </div>
            <div className="sheet-scroll">
            {sheetNames.map((sheet, index) => (
              <div
                key={sheet}
                className={`sheet-item ${
                  activeSheet === sheet ? "active" : ""
                }`}
                onClick={() => setActiveSheet(sheet)}
              >
                <div className="sheet-index">
                  {(index + 1).toString().padStart(2, "0")}
                </div>

                <RiFileExcel2Line className="sheet-icon" />

                <div className="sheet-name">{sheet.replaceAll("_", " ")}</div>
              </div>
            ))}
            </div>
          </div>

          {/* RIGHT */}

          <div className="sheet-viewer">
            <div
              className="excel-wrapper"
              style={{
                transform: `scale(${zoom})`,
              }}
            >
              {!loading && !error && (
                <table className="excel-table">
                  <tbody>
                    {filteredRows.map((row, rowIndex) => (
                      <tr key={rowIndex}>
                        {/* Row Number */}

                        <td className="row-number">{rowIndex + 1}</td>

                        {row.map((cell, colIndex) => (
                          <td
                            key={colIndex}
                            className={rowIndex === 0 ? "header-cell" : ""}
                          >
                            {cell}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
