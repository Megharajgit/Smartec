import "../styles/knowledgeRepository.css";

// ------------------------------------------------------------------
// Icons
// ------------------------------------------------------------------

function DocIcon({ size = 18, color = "#475569" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <path d="M14 2v6h6" />
      <line x1="8" y1="13" x2="16" y2="13" />
      <line x1="8" y1="17" x2="16" y2="17" />
    </svg>
  );
}

function FileIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="vault-row-file-icon">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <path d="M14 2v6h6" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="7" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}

function ChevronIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#475569" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
  );
}

// ------------------------------------------------------------------
// Data — replace with your real vault data source
// ------------------------------------------------------------------

const STATUS_STYLES = {
  Approved: { color: "#15803D", bg: "#DCFCE7", dot: "#16A34A" },
  "In Review": { color: "#1D4ED8", bg: "#DBEAFE", dot: "#2563EB" },
  "Pending Approval": { color: "#B45309", bg: "#FEF3C7", dot: "#D97706" },
  Draft: { color: "#475569", bg: "#F1F5F9", dot: "#94A3B8" },
};

const AVATAR_COLORS = {
  JW: "#2563EB",
  PN: "#0D9488",
  MT: "#D97706",
  SC: "#7C3AED",
};

const sops = [
  {
    id: "SOP-VLT-0231",
    name: "Claims Authorization Validation SOP",
    useCase: "Authorization Validation",
    version: "v3.2",
    revisions: 4,
    uploadedBy: "James Wilson",
    initials: "JW",
    date: "10 Jun 2026",
    time: "11:15 AM",
    status: "Approved",
  },
  {
    id: "SOP-VLT-0198",
    name: "CAS PCPEND Edit Resolution SOP",
    useCase: "Claims Processing",
    version: "v2.4",
    revisions: 6,
    uploadedBy: "Priya Nair",
    initials: "PN",
    date: "08 Jun 2026",
    time: "09:30 AM",
    status: "Approved",
  },
  {
    id: "SOP-VLT-0176",
    name: "EHub Cross-System Validation SOP",
    useCase: "Cross-System Validation",
    version: "v1.4",
    revisions: 3,
    uploadedBy: "Michael Torres",
    initials: "MT",
    date: "05 Jun 2026",
    time: "03:50 PM",
    status: "In Review",
  },
  {
    id: "SOP-VLT-0165",
    name: "CGX Authorization Evidence Review SOP",
    useCase: "Authorization Validation",
    version: "v2.0",
    revisions: 2,
    uploadedBy: "Sarah Chen",
    initials: "SC",
    date: "02 Jun 2026",
    time: "01:10 PM",
    status: "Approved",
  },
  {
    id: "SOP-VLT-0142",
    name: "Provider Tax ID Reconciliation SOP",
    useCase: "Provider Reconciliation",
    version: "v1.9",
    revisions: 5,
    uploadedBy: "James Wilson",
    initials: "JW",
    date: "28 May 2026",
    time: "10:05 AM",
    status: "Pending Approval",
  },
  {
    id: "SOP-VLT-0131",
    name: "Behavioral Health Claim Routing SOP",
    useCase: "Behavioral Health Routing",
    version: "v1.0",
    revisions: 1,
    uploadedBy: "Priya Nair",
    initials: "PN",
    date: "22 May 2026",
    time: "04:20 PM",
    status: "Draft",
  },
  {
    id: "SOP-VLT-0119",
    name: "Timely Filing Exception Handling SOP",
    useCase: "Exception Handling",
    version: "v2.1",
    revisions: 3,
    uploadedBy: "Michael Torres",
    initials: "MT",
    date: "18 May 2026",
    time: "08:45 AM",
    status: "Approved",
  },
  {
    id: "SOP-VLT-0104",
    name: "Manual SOP Review Escalation Process",
    useCase: "Manual Review Escalation",
    version: "v1.1",
    revisions: 2,
    uploadedBy: "Sarah Chen",
    initials: "SC",
    date: "12 May 2026",
    time: "02:30 PM",
    status: "Pending Approval",
  },
  {
    id: "SOP-VLT-0087",
    name: "Exclusion List Verification SOP",
    useCase: "Provider Reconciliation",
    version: "v3.0",
    revisions: 4,
    uploadedBy: "James Wilson",
    initials: "JW",
    date: "05 May 2026",
    time: "09:00 AM",
    status: "Approved",
  },
];

// ------------------------------------------------------------------
// Row
// ------------------------------------------------------------------

function VaultRow({ sop }) {
  const statusStyle = STATUS_STYLES[sop.status] || STATUS_STYLES.Draft;
  const avatarColor = AVATAR_COLORS[sop.initials] || "#64748B";

  return (
    <div className="vault-row vault-row-grid">
      <div className="vault-row-name-cell">
        <FileIcon />
        <div>
          <div className="vault-row-name">{sop.name}</div>
          <div className="vault-row-id">{sop.id}</div>
        </div>
      </div>

      <div>
        <span className="vault-tag">{sop.useCase}</span>
      </div>

      <div>
        <div className="vault-version">{sop.version}</div>
        <div className="vault-revisions">
          {sop.revisions} {sop.revisions === 1 ? "revision" : "revisions"}
        </div>
      </div>

      <div className="vault-uploader">
        <div className="vault-avatar" style={{ background: avatarColor }}>
          {sop.initials}
        </div>
        <span>{sop.uploadedBy}</span>
      </div>

      <div>
        <div className="vault-date">{sop.date}</div>
        <div className="vault-time">{sop.time}</div>
      </div>

      <div>
        <span
          className="vault-status-pill"
          style={{ color: statusStyle.color, background: statusStyle.bg }}
        >
          <span className="vault-status-dot" style={{ background: statusStyle.dot }} />
          {sop.status}
        </span>
      </div>

      <div className="vault-actions">
        <button className="vault-action-btn" title="View">
          <EyeIcon />
        </button>
        <button className="vault-action-btn" title="Download">
          <DownloadIcon />
        </button>
      </div>
    </div>
  );
}

// ------------------------------------------------------------------
// Page
// ------------------------------------------------------------------

export default function KnowledgeRepository() {
  return (
    <div className="vault-page">
      <div className="vault-page-header">
        <div>
          <h1>Smart SOP Vault</h1>
          <p>
            Every validated Smart SOP, versioned and approval-tracked in one
            place — pulled in whenever an agent needs current procedure
            guidance.
          </p>
        </div>

        <div className="vault-meta">
          <div className="vault-meta-count">{sops.length} SOPs in vault</div>
          <div className="vault-meta-sync">Synced 10 Jun 2026, 11:40 AM</div>
        </div>
      </div>

      <div className="vault-card">
        <div className="vault-toolbar">
          <div className="vault-toolbar-title">
            <DocIcon />
            <span>All Smart SOPs</span>
          </div>

          <div className="vault-toolbar-controls">
            <div className="vault-search">
              <SearchIcon />
              <span>Search SOPs...</span>
            </div>

            <div className="vault-filter">
              <span>Use Case: All</span>
              <ChevronIcon />
            </div>

            <div className="vault-filter">
              <span>Status: All</span>
              <ChevronIcon />
            </div>
          </div>
        </div>

        <div className="vault-table-header vault-row-grid">
          <span>SOP NAME</span>
          <span>USE CASE</span>
          <span>VERSION</span>
          <span>UPLOADED BY</span>
          <span>UPLOAD DATE</span>
          <span>STATUS</span>
          <span className="vault-actions-header">ACTIONS</span>
        </div>

        {sops.map((sop) => (
          <VaultRow key={sop.id} sop={sop} />
        ))}
      </div>
    </div>
  );
}
