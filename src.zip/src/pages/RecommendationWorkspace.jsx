import { useParams, Link, useNavigate } from "react-router-dom";

import { claims } from "../data/claimsData";
import { useClaim } from "../context/ClaimContext";

import RecommendationCard from "../components/RecommendationCard";
import KnowledgeAssetsCard from "../components/KnowledgeAssetsCard";

import "../styles/recommendationWorkspace.css";
import { useEffect } from "react";

export default function RecommendationWorkspace() {
  const {setMaxUnlockedStage,setWorkflowType} = useClaim();
  useEffect(() => {
    setMaxUnlockedStage(3);
}, []);

  const { claimId } = useParams();
  const navigate = useNavigate();

const handleApprove = () => {
  setWorkflowType("approve");
  navigate(`/execution/${claimId}`);
};

const handleReject = () => {
  setWorkflowType("reject");
  navigate(`/route/${claimId}`);
};

const handleReview = (action) => {
  switch (action) {
    case "Reject Recommendation":
    case "Request more info":
      navigate(`/route/${claimId}`);
      break;

    case "Escalate for Review":
    case "Approve for Reprocessing":
    default:
      navigate(`/execution/${claimId}`);
      break;
  }
};

  const claim = claims.find((c) => c.id === claimId);

  if (!claim) {
    return <h2>Claim not found</h2>;
  }

  return (
    <div className="recommendation-page">


      {/* ---------------- Main Layout ---------------- */}

      <div className="recommendation-layout">

        <RecommendationCard 
        onApprove={handleApprove}
        onReject={handleReject}
        onReview={handleReview}
        claim={claim}
        />

        <KnowledgeAssetsCard
        claim={claim} />

      </div>

    </div>
  );
}