import { useParams } from "react-router-dom";
import ExecutionCard from "../components/ExecutionCard";
import { useClaim } from "../context/ClaimContext";
import { useEffect } from "react";
export default function Execution() {
  const {setMaxUnlockedStage,claims} = useClaim();
  useEffect(() => {
    setMaxUnlockedStage(4);
}, []);
  
  const { claimId } = useParams();
  const claim = claims.find((c) => c.id === claimId);
  
    if (!claim) {
      return <h2>Claim not found</h2>;
    }
  
  return (
    <div>
      <ExecutionCard claim={claim}/>
    </div>
  );
}