import { useNavigate, useParams, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { claims } from "../data/claimsData";
import { useClaim } from "../context/ClaimContext";
import SOPModal from "../components/SOPModal";
import ManualSOPModal from "../components/ManualSOPModal";
import FlowModal from "../components/FlowModal";
import { RiBookOpenLine, RiInformationLine, RiAlertLine } from "react-icons/ri";
import "../styles/scenarioDiscovery.css";

export default function ScenarioDiscovery() {
  const { setMaxUnlockedStage } = useClaim();
  useEffect(() => {
    setMaxUnlockedStage(2);
}, []);
  
  const navigate = useNavigate();
  const { claimId } = useParams();

  const claim = claims.find((c) => c.id === claimId);
  const confidence = claim?.Scenario?.confidence || 91;

  const confidenceLabel =
    confidence >= 90
      ? "High Confidence"
      : confidence >= 75
        ? "Medium Confidence"
        : "Low Confidence";

  const scenarioTitle =
    claim?.Scenario?.title || "COC Found but Not Applicable";

  const progressColor =
    confidence >= 90 ? "#3B82F6" : confidence >= 75 ? "#F59E0B" : "#EF4444";

  const [showSOP, setShowSOP] = useState(false);
  const [showManualSOP, setShowManualSOP] = useState(false);
  const [finalAction, setFinalAction] = useState("");
  const [showFlow, setShowFlow] = useState(false);

  if (!claim) return <h2>Claim not found</h2>;
  const scenario = claim?.Scenario;
  const warnings = scenario?.warnings || [];
  // const warnings = [
  //   {
  //     severity: "High",
  //     title: "WFWM UM Auth - PEND",
      
  //     description:
  //       "This claim requires UM Authorization review before processing. An active WFWM UM Auth - PEND flag has been detected.",
  //   },

  // ];

  const badgeClass = (severity) => {
    if (severity === "High") return "high";
    if (severity === "Medium") return "medium";
    return "low";
  };
  const [recommendationMode, setRecommendationMode] = useState("AI Assisted");
  return (
    <div className="scenario-page">
      {/* ================= Layout ================= */}

      <div className="scenario-layout">
        {/* LEFT */}

        <div className="warning-panel">
          <h2>
            <RiAlertLine color="red" /> Warnings & Alerts
          </h2>

          <p>System-detected flags requiring attention before processing</p>

          {warnings.map((warning, index) => (
            <div
              key={index}
              className={`warning-card ${badgeClass(warning.severity)}`}
            >
              <div className="warning-header">
                <h4>{warning.title}</h4>

                <span className={`severity ${badgeClass(warning.severity)}`}>
                  {warning.severity}
                </span>
              </div>

              <p>{warning.description}</p>
            </div>
          ))}
         
        </div>

        {/* RIGHT */}

        <div className="classification-panel">
          <h2>Scenario Classification</h2>

          <p>Scenario automatically identified for this claim</p>

          <div className="classification-box">
            <div className="scenario-row">
              <label>Suggested Scenario</label>

              <span className="scenario-badge">
                {claim.Scenario.title || "UM Authorization / COC - Mismatch"}
              </span>
            </div>

            <div className="scenario-row">
              <label>Scenario Family</label>

              <span>{claim.Scenario.family || "UM Authorization"}</span>
            </div>

            <div className="scenario-row">
              <label>Scenario Confidence</label>

              <span className="confidence-value">
                {claim.Scenario.confidence}%
              </span>
            </div>

            <div className="confidence-bar">
              <div
                className="confidence-fill"
                style={{
                  width: `${claim.Scenario.confidence}%`,
                }}
              />
            </div>

            <div className="scenario-row rationale">
              <label>Scenario Rationale</label>
            </div>

            <div className="rationale-box">{claim.Scenario.rationale}</div>
          </div>

       

          <label style={{ marginTop: "30px" }}>
            Select a Different Scenario
          </label>

          <select
            value={finalAction}
            onChange={(e) => setFinalAction(e.target.value)}
          >
            <option>--System Selected--</option>


            <option>Coordination of Benefits</option>
            <option>Timely Filing</option>
            <option>Duplicate Claim</option>
            <option>Eligibility</option>
            <option>Medical Necessity</option>
            <option>Pricing / Provider Contract</option>
            <option>Other / Manual Review</option>
          </select>

          {finalAction && finalAction !== "--System Selected--" && (
            <div className="override-banner">
              <RiInformationLine />
              Agent Override: "{finalAction}" selected. SOP reference updated.
            </div>
          )}

          <div className="classification-footer">
            <button
              className="manual-sop-btn"
              onClick={() => setShowManualSOP(true)}
            >
              <RiBookOpenLine />
              View Manual SOP
            </button>
            <button className="manual-sop-btn" onClick={() => setShowSOP(true)}>
              📘 Smart SOP
            </button>

            <button
              className="manual-sop-btn"
              onClick={() => setShowFlow(true)}
            >
              🧭 Flowchart
            </button>

            <button
              className="scenario-next-btn"
              onClick={() => navigate(`/recommendation-workspace/${claim.id}`)}
            >
              Generate Recommendation →
            </button>
          </div>
        </div>
      </div>

      <SOPModal open={showSOP} onClose={() => setShowSOP(false)} />
      <ManualSOPModal
        open={showManualSOP}
        onClose={() => setShowManualSOP(false)}
      />
      <FlowModal open={showFlow} onClose={() => setShowFlow(false)} />
    </div>
  );
}
