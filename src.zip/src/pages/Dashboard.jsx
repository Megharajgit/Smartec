import DashboardHeader from "../components/DashboardHeader";
import KPICard from "../components/KPICard";
import MetricCards from "../components/MetricCards";
import ScenarioChart from "../components/ScenarioChart";
import TrendChart from "../components/TrendChart";
import PlatformChart from "../components/PlatformChart";
import DashboardBottom from "../components/DashboardBottom";

import "../styles/dashboard.css";

export default function Dashboard() {

    return (

        <div className="dashboard-page">

            <DashboardHeader />

            <KPICard />

            <MetricCards />

            <div className="dashboard-charts">

                <ScenarioChart />

                <TrendChart />

                <PlatformChart />

            </div>

            <DashboardBottom />

            <div className="dashboard-footer">

                All times are local time (UTC).
                Data refreshed every 2 minutes ·
                Last Refreshed: 10 Jun 2026, 09:30 AM

            </div>

        </div>

    );

}