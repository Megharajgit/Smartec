import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import CasEhubCgxValidation from "../components/CasEhubCgxValidation";

import { claims } from "../data/claimsData";

import "../styles/validationWorkspace.css";

import SourceDocuments from "../components/SourceDocuments";
import ExtractedClaimData from "../components/ExtractedClaimData";
import SmartValidation from "../components/SmartValidation";
import { useClaim } from "../context/ClaimContext";

export default function ValidationWorkspace() {
  const navigate = useNavigate();
  const { setMaxUnlockedStage } = useClaim();
  useEffect(() => {
    setMaxUnlockedStage(1);
  }, []);
  const { claimId } = useParams();

  const claim = claims.find((c) => c.id === claimId);

  const [approved, setApproved] = useState(false);

  const editMode = true;

  // Fields highlighted on UB04
  const [highlightedFields, setHighlightedFields] = useState([]);

  // Values edited by user
  const [editedFields, setEditedFields] = useState({});

  const workspaceType = claim?.workspaceType || "STANDARD";
  // Check screen:
  if (workspaceType === "SPECIAL") {
    return <CasEhubCgxValidation claim={claim} />;
  // return (
  //   <div className="validation-page">
  //     {/* NEW SPECIAL VALIDATION UI */}
  //     <h1>Yes</h1>
  //   </div>
  // );
}

  if (!claim) {
    return <h2>Claim not found</h2>;
  }
  const hasData =
    claim?.applicationData?.length || claim?.notes || claim?.formType;

  if (!hasData) {
    return (
      <div className="validation-page">
        <div
          style={{
            height: "70vh",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
            textAlign: "center",
          }}
        >
          <h2>📄 All the claim Data is auto Validated</h2>
          <br />
          <p>
            The claim was found, since this is EDI-837 transaction, all the claim data is auto validated.
          </p>
          <br />
          <button
            style={{ padding: "4px" }}
            className={`footer-btn proceed`}
            onClick={() => navigate(`/scenario-discovery/${claim.id}`)}
          >
            Proceed to Scenario Discovery →
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="validation-page">
      {/* ================= Workspace ================= */}

      <div className="workspace-layout">
        {/* LEFT */}
        <div className="panel">
          <SmartValidation
            claim={claim}
            approved={approved}
            setApproved={setApproved}
            editMode={editMode}
            highlightedFields={highlightedFields}
            // setEditMode={setEditMode}
          />
        </div>

        {/* CENTER */}

        <div className="panel">
          <ExtractedClaimData
            claim={claim}
            editMode={editMode}
            approved={approved}
            setApproved={setApproved}
            highlightedFields={highlightedFields}
            setHighlightedFields={setHighlightedFields}
            editedFields={editedFields}
            setEditedFields={setEditedFields}
          />
        </div>

        {/* RIGHT */}
        <div className="panel">
          <SourceDocuments
            claim={claim}
            highlightedFields={highlightedFields}
            editedFields={editedFields}
          />
        </div>
      </div>
    </div>
  );
}
