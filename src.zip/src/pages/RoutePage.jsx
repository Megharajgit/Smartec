import { Link, useNavigate, useParams } from "react-router-dom";

import { useEffect, useState } from "react";
import { useClaim } from "../context/ClaimContext";

import SuccessModal from "../components/SuccessModal";
import RecommendationRejectedCard from "../components/RecommendationRejectedCard";
import RouteSelectionCard from "../components/RouteSelectionCard";
import RoutingSummaryCard from "../components/RoutingSummaryCard";

import "../styles/route.css";

export default function Route() {
  const { setMaxUnlockedStage,claims,setClaims } = useClaim();
  useEffect(() => {
    setMaxUnlockedStage(5);
}, []);
  
  const navigate = useNavigate();
  const { claimId } = useParams();

  const [showModal, setShowModal] = useState(false);

  const [modalData, setModalData] = useState({
    title: "",
    message: "",
  });
  const claim = claims.find((c) => c.id === claimId);
  const [selectedTeam, setSelectedTeam] = useState({
    team: "Benefits Team",
    assignedTo: "Shatvik Pandey",
    reason: "Pricing Rule",
  });

  if (!claim) {
    return <h2>Claim not found</h2>;
  }
  const executeRouteBot = async () => {
    try {
      setModalData({
        title: "Processing Route",
        message: "Route automation is running. Please wait...",
      });

      setShowModal(true);

      const response = await fetch("http://localhost:5000/route-claim", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          claimId: claim.id,
          team: selectedTeam.team,
          assignedTo: selectedTeam.assignedTo,
          reason: selectedTeam.reason,
        }),
      });

      const result = await response.json();
      setClaims((prev) =>
        prev.map((c) =>
          c.id === claim.id ? { ...c, status: "PROCESSED" } : c,
        ))

        setModalData({
          title: "Claim Routed Successfully",
          message: `Claim ${claim.id} has been routed successfully to ${selectedTeam.team}.`,
        });
        
        setShowModal(true);
     
    } catch (error) {
      console.error(error);

      setModalData({
        title: "Execution Error",
        message: "Unable to execute routing automation.",
      });

      setShowModal(true);
    }
  };

  return (
    <div className="route-page">
      {/* ================= Layout ================= */}

      <div className="route-layout">
        <RecommendationRejectedCard claim={claim} />

        <RouteSelectionCard
          selectedTeam={selectedTeam}
          setSelectedTeam={setSelectedTeam}
          claim={claim}
        />

        <RoutingSummaryCard claim={claim} selectedTeam={selectedTeam} />
      </div>

      {/* ================= Footer ================= */}

      <div className="route-footer">
        <div>
          <button className="cancel-btn" onClick={() => navigate(-1)}>
            ← Cancel
          </button>

       
          <button
            className="draft-btn"
            onClick={() => {
              setModalData({
                title: "Draft Saved",
                message:
                  "Your routing information has been saved successfully. You can continue later from your drafts.",
              });

              setShowModal(true);
            }}
          >
            Save as Draft
          </button>
        </div>

        
        <button className="route-btn" onClick={executeRouteBot}>
          Route Claim →
        </button>
      </div>
      <SuccessModal
        open={showModal}
        title={modalData.title}
        message={modalData.message}
        buttonText="Done"
        onClose={() => {
          setShowModal(false);

          if (modalData.title === "Claim Routed Successfully") {
            navigate("/claim-inventory");
          }
        }}
      />
    </div>
  );
}
