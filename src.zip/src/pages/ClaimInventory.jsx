import {
  RiFileList2Line,
  RiCheckboxCircleLine,
  RiPulseLine,
  RiAlarmWarningLine,
  RiAlertLine,
  RiRefreshLine,
  RiSearchLine,
  RiArrowDownSLine,
  RiShieldCheckLine,
  RiErrorWarningLine,
} from "react-icons/ri";
import "../styles/claimInventory.css";
import { useEffect, useState } from "react";
import DateRangeDropdown from "../components/DateRangeDropdown";
import FilterDropdown from "../components/FilterDropdown";
import { Link } from "react-router-dom";
import { useClaim } from "../context/ClaimContext";

export default function ClaimInventory() {
  const { setSelectedClaim,claims,setMaxUnlockedStage } = useClaim();
  useEffect(() => {
    setMaxUnlockedStage(0);
}, []);
  claims.filter(c =>
    c.status !== "PROCESSED" &&
    c.status !== "ROUTED"
)
  const openClaim = (claim) => {
    setSelectedClaim(claim);
    
    navigate(`/validation-workspace/${claim.claimId}`);
  };
  const rowsPerPage = 8;

  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const [dateRange, setDateRange] = useState("10 Jun 2026 - 10 Jun 2026");
  const [showDateDropdown, setShowDateDropdown] = useState(false);

  const [source, setSource] = useState("All");
  const [platform, setPlatform] = useState("All");
  const [priority, setPriority] = useState("All");
  const [status, setStatus] = useState("All");

  const [openDropdown, setOpenDropdown] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = () => {
    setRefreshing(true);

    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  const sourceItems = [
    "All",
    "Paper Claim",
    "EDI 837",
  ];
  const platformItems = ["All", "Facets", "HRP", "CAS"];
  const priorityItems = ["All", "High", "Medium", "Low"];
  const statusItems = [
    "All",
    "Ready for Review",
    "In Progress",
    "Escalated",
    "Validate",
  ];

  
  const filteredClaims = claims.filter((claim) => {
  // Don't show processed/routed claims
  if (
    claim.status === "PROCESSED" ||
    claim.status === "ROUTED"
  ) {
    return false;
  }

  const searchMatch =
    claim.id.toLowerCase().includes(search.toLowerCase()) ||
    claim.member.toLowerCase().includes(search.toLowerCase());

  const sourceMatch =
    source === "All" || claim.source === source;

  const platformMatch =
    platform === "All" || claim.platform === platform;

  const priorityMatch =
    priority === "All" || claim.priority === priority;

  const statusMatch =
    status === "All" || claim.status === status;

  return (
    searchMatch &&
    sourceMatch &&
    platformMatch &&
    priorityMatch &&
    statusMatch
  );
});
  const totalClaims = filteredClaims.length;

  const readyClaims = filteredClaims.filter(
    (c) => c.status === "Ready for Review",
  ).length;

  const progressClaims = filteredClaims.filter(
    (c) => c.status === "In Progress",
  ).length;

  const escalatedClaims = filteredClaims.filter(
    (c) => c.priority === "High",
  ).length;

  const validateClaims = filteredClaims.filter(
    (c) => c.status === "In Progress" && c.priority === "High",
  ).length;

  const totalPages = Math.ceil(filteredClaims.length / rowsPerPage);

  const currentClaims = filteredClaims.slice(
    (currentPage - 1) * rowsPerPage,

    currentPage * rowsPerPage,
  );
  return (
    <div className="claim-page">
      <div className="page-top">
        <h1>Claim Inventory</h1>
        <button
          className="refresh-btn"
          onClick={handleRefresh}
          disabled={refreshing}
        >
          <RiRefreshLine className={refreshing ? "spin" : ""} />
          {refreshing ? "Refreshing..." : "Refresh"}
        </button>
      </div>

      <div className="filter-panel">
        <div className="filters">
          <div className="filter-group">
            <label>Source</label>

            <div className="dropdown-wrapper">
              <button
                className="filter-btn"
                onClick={() =>
                  setOpenDropdown(openDropdown === "source" ? "" : "source")
                }
              >
                {source}

                <RiArrowDownSLine />
              </button>

              {openDropdown === "source" && (
                <FilterDropdown
                  width={175}
                  items={sourceItems}
                  selected={source}
                  onSelect={(value) => {
                    setSource(value);
                    setCurrentPage(1);
                    setOpenDropdown("");
                  }}
                />
              )}
            </div>
          </div>
          <div className="filter-group">
            <label>Priority</label>

            <div className="dropdown-wrapper">
              <button
                className="filter-btn"
                onClick={() =>
                  setOpenDropdown(openDropdown === "priority" ? "" : "priority")
                }
              >
                {priority}

                <RiArrowDownSLine />
              </button>

              {openDropdown === "priority" && (
                <FilterDropdown
                  width={120}
                  items={priorityItems}
                  selected={priority}
                  onSelect={(value) => {
                    setPriority(value);
                    setCurrentPage(1);
                    setOpenDropdown("");
                  }}
                />
              )}
            </div>
          </div>
          <div className="filter-group">
            <label>Platform</label>

            <div className="dropdown-wrapper">
              <button
                className="filter-btn"
                onClick={() =>
                  setOpenDropdown(openDropdown === "platform" ? "" : "platform")
                }
              >
                {platform}

                <RiArrowDownSLine />
              </button>

              {openDropdown === "platform" && (
                <FilterDropdown
                  width={120}
                  items={platformItems}
                  selected={platform}
                  onSelect={(value) => {
                    setPlatform(value);
                    setCurrentPage(1);
                    setOpenDropdown("");
                  }}
                />
              )}
            </div>
          </div>
        </div>

      </div>

      <div className="stats-row">
        <div className="stat-card blue">
          <div className="stat-icon">
            <RiFileList2Line />
          </div>

          <div>
            <div className="stat-number">{totalClaims}</div>

            <div className="stat-label">Total Claims</div>
          </div>
        </div>

        <div className="stat-card green">
          <div className="stat-icon">
            <RiCheckboxCircleLine />
          </div>

          <div>
            <div className="stat-number">{totalClaims}</div>

            <div className="stat-label">Ready for Review</div>
          </div>
        </div>

        <div className="stat-card red">
          <div className="stat-icon">
            <RiAlertLine />
          </div>

          <div>
            <div className="stat-number">{escalatedClaims}</div>

            <div className="stat-label">High Priority</div>
          </div>
        </div>
        <div className="stat-card yellow">
          <div className="stat-icon">
            <RiErrorWarningLine />
          </div>

          <div>
            <div className="stat-number">{validateClaims}</div>

            <div className="stat-label">Escalated</div>
          </div>
        </div>
        
      </div>

      <div className="table-panel">
        <div className="table-toolbar">
          <div className="search-box">
            <RiSearchLine />

            <input
              type="text"
              placeholder="Search Claim ID or MemberID"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="search-input"
            />
          </div>
        </div>
        <table className="claims-table-main">
          <thead>
            <tr>
              <th>CLAIM ID</th>

              <th>PLATFORM</th>

              <th>SOURCE</th>

              <th>RECEIVED DATE</th>

              <th>MEMBER ID</th>

              <th>PROVIDER</th>

              {/* <th>STATUS</th> */}

              <th>PRIORITY</th>

              <th>ACTION</th>
            </tr>
          </thead>

          <tbody>
            {currentClaims.map((claim) => (
              <tr key={claim.id}>
                <td>
                  <Link
                    // to={`/validation-workspace/${claim.id}`}
                     to={
    claim.show === "yes"
      ? `/validation-workspace/${claim.id}`
      : `/scenario-discovery/${claim.id}`
  }
                    onClick={() => setSelectedClaim(claim)}
                    className={"claim-link"}
                  >
                    {claim.id}
                  </Link>
                </td>

                <td>{claim.platform}</td>

                <td>{claim.source}</td>

                <td>{claim.date}</td>

                <td>{claim.member}</td>

                <td>{claim.provider}</td>

                <td>
                  <span
                    className={`priority ${
                      claim.priority === "High"
                        ? "high"
                        : claim.priority === "Medium"
                          ? "medium"
                          : "low"
                    }`}
                  >
                    {claim.priority}
                  </span>
                </td>

                <td>
                  <Link
                    
                     to={
    claim.show === "yes"
      ? `/validation-workspace/${claim.id}`
      : `/scenario-discovery/${claim.id}`
  }
                    onClick={() => setSelectedClaim(claim)}
                    className={"action-link"}
                  >
                    Open Claim →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="table-footer">
          <div className="entries-info">
            Showing{" "}
            {filteredClaims.length === 0
              ? 0
              : (currentPage - 1) * rowsPerPage + 1}{" "}
            to {Math.min(currentPage * rowsPerPage, filteredClaims.length)} of{" "}
            {filteredClaims.length} entries
          </div>

          <div className="pagination">
            <button
              className="page-btn"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              ‹
            </button>

            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i}
                className={`page-btn ${currentPage === i + 1 ? "active" : ""}`}
                onClick={() => setCurrentPage(i + 1)}
              >
                {i + 1}
              </button>
            ))}

            <button
              className="page-btn"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              ›
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
