import { Routes, Route, Navigate } from "react-router-dom";

import Layout from "./components/Layout";

import ClaimInventory from "./pages/ClaimInventory";
import ValidationWorkspace from "./pages/ValidationWorkspace";
import ScenarioDiscovery from "./pages/ScenarioDiscovery";
import RecommendationWorkspace from "./pages/RecommendationWorkspace";
import Execution from "./pages/Execution";
import RoutePage from "./pages/RoutePage";
import Dashboard from "./pages/Dashboard";
import KnowledgeRepository from "./pages/KnowledgeRepository";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Navigate to="/claim-inventory" replace />} />

        <Route path="claim-inventory" element={<ClaimInventory />} />
        <Route
    path="validation-workspace/:claimId"
    element={<ValidationWorkspace />}
/>
        <Route path="scenario-discovery/:claimId" element={<ScenarioDiscovery />} />
        <Route
          path="recommendation-workspace/:claimId"
          element={<RecommendationWorkspace />}
        />
        <Route path="execution/:claimId" element={<Execution />} />
        <Route path="route/:claimId" element={<RoutePage />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="knowledge-repository" element={<KnowledgeRepository />} />
      </Route>
    </Routes>
  );
}

export default App;
